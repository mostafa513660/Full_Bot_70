import telebot
import csv
import uuid
import re
from datetime import datetime, timedelta

bot = telebot.TeleBot("5929009539:AAG18NDhJ8JzMnh-Kx64Ne0qAq3EG2OI91w")

admin = 5894339732
csv_file = "databases/user_data.csv"
keys_file = "databases/keys.csv"
claimed_keys_file = "databases/claimed_keys.csv"


def get_level(key):
    try:
        with open(keys_file, 'r') as csvfile:
            reader = csv.reader(csvfile)
            for row in reader:
                if row and row[0] == key:
                    return row[1]
        return None
    except Exception as e:
        print(f"Error: {e}")
        return None

def parse_duration(duration_str):
    days = 0
    hours = 0
    months = 0
    years = 0
    matches = re.findall(r'(\d+)([dhmy])', duration_str)
    for value, unit in matches:
        value = int(value)
        if unit == 'd':
            days += value
        elif unit == 'h':
            hours += value
        elif unit == 'm':
            months += value
        elif unit == 'y':
            years += value
    total_days = days + months * 30 + years * 365
    return timedelta(days=total_days, hours=hours)

@bot.message_handler(commands=['gen'])
def generate_key(message):
    if message.chat.id != admin:
        bot.reply_to(message, "Unauthorized")
        return
    try:
        parts = message.text.split()
        key = str(uuid.uuid4())
        level = "premium"
        duration_str = None

        if len(parts) >= 2:
            level = parts[1]

        if len(parts) >= 3:
            print(parts)
            duration_str = ' '.join(parts[2:])


        if duration_str:
            try:
                expiration_time = (datetime.now() + parse_duration(duration_str)).strftime("%Y-%m-%d %H:%M:%S")
            except ValueError as e:
                bot.send_message(message.chat.id, str(e))
                return
        else:
            expiration_time = "N/A"

        with open(keys_file, 'a', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow([key, level, expiration_time])

        bot.send_message(message.chat.id, f"Key generated: {key}\nLevel: {level}\nExpiration: {expiration_time}")
    except Exception as e:
        bot.send_message(message.chat.id, f"Error: {e}")

@bot.message_handler(commands=['claim'])
def claim_key(message):
    try:
        parts = message.text.split()
        if len(parts) < 2:
            bot.send_message(message.chat.id, "Invalid command. Use /claim key.")
            return
        key = parts[1]
        with open(claimed_keys_file, 'r') as claimed_keys:
            claimed_keys_reader = csv.reader(claimed_keys)
            for claimed_key in claimed_keys_reader:
                if key == claimed_key[0]:
                    bot.send_message(message.chat.id, "Key has already been claimed.")
                    return
                       
        with open(csv_file, 'r') as data:
            data_reader = csv.reader(data)
            for row in data_reader:
                current_time = datetime.now()
                expiration_time_str = row[2]
                expiration_time = datetime.strptime(expiration_time_str, "%Y-%m-%d %H:%M:%S")
                if len(row) >= 2 and str(message.chat.id) == row[0] and current_time >= expiration_time:
                	with open(csv_file, 'w') as data:
	                	lines = data.readlines()
	                	print(lines)
	                	for line in lines:
	                		if not line.startswith(message.chat.id):
	                			data.write(line)
                if len(row) >= 2 and str(message.chat.id) == row[0]:
                    bot.reply_to(message, "You Already Have a Subscription")
                    return
        with open(keys_file, 'r') as keys:
            keys_reader = csv.reader(keys)
            for row in keys_reader:
                if key == row[0]:
                    expiration_time = row[2]
                    with open(csv_file, 'a', newline='') as csvfile:
                        writer = csv.writer(csvfile)
                        writer.writerow([message.chat.id, key, expiration_time])
                    bot.send_message(message.chat.id, "Subscription activated.")
                    return
        bot.send_message(message.chat.id, "Key not found or expired.")
    except Exception as e:
        bot.send_message(message.chat.id, f"Error: {e}")
        with open(keys_file, 'r') as keys:
            keys_reader = csv.reader(keys)
            for row in keys_reader:
                if key == row[0]:
                    expiration_time = row[2]
                    with open(csv_file, 'a', newline='') as csvfile:
                        writer = csv.writer(csvfile)
                        writer.writerow([message.chat.id, key, expiration_time])
                    
                    with open(claimed_keys_file, 'a', newline='') as claimed_keys:
                        claimed_keys_writer = csv.writer(claimed_keys)
                        claimed_keys_writer.writerow([key])
                    
                    bot.send_message(message.chat.id, "Subscription activated.")
                    return

        bot.send_message(message.chat.id, "Key not found or expired.")
    except Exception as e:
        bot.send_message(message.chat.id, f"Error: {e}")


@bot.message_handler(commands=['start'])
def start(message):
    with open(csv_file, 'r') as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            if str(message.chat.id) == row[0]:
                level = get_level(row[1])
                expiration_time_str = row[2]
                current_time = datetime.now()
                expiration_time = datetime.strptime(expiration_time_str, "%Y-%m-%d %H:%M:%S")
                if current_time <= expiration_time:
                    bot.send_message(message.chat.id, f"Telegram ID: {message.chat.id}\nSubscription: {level}\nExpiration: {expiration_time_str}")
                else:
                    bot.send_message(message.chat.id, f"Telegram ID: {message.chat.id}\nSubscription: [has expired]")
                return
        bot.send_message(message.chat.id, "You have no subscription.")

bot.polling()