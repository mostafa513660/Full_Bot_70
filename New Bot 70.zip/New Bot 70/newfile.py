import csv
from datetime import datetime

def user_has_access(user_id, csv_file):
    try:
        current_time = datetime.now()
        with open(csv_file, 'r') as csvfile:
            reader = csv.reader(csvfile)
            for row in reader:
                if str(user_id) == row[0]:
                    expiration_time_str = row[2]
                    expiration_time = datetime.strptime(expiration_time_str, "%Y-%m-%d %H:%M:%S")
                    if current_time <= expiration_time:
                        return True
                    else:
                        return False
            return False
    except Exception as e:
        print(f"Error: {e}")
        return False

user_id = 589433973
csv_file = "databases/user_data.csv"

has_access = user_has_access(user_id, csv_file)
if has_access:
    print("User has access to the bot.")
else:
    print("User does not have access to the bot or access has expired.")
