from paypal import process_card_p

card = "4033060047342909|08|28|667"

print(process_card_p(card))